from odoo import fields, models

class Question(models.Model):
    _name = "question"
    _rec_name = 'id'

    question = fields.Char(string="Question")
    response = fields.Text(string="Response")
    
    def serialize(self):
        return {
            'question': self.question,
            'response': self.response,
        }

