from odoo import fields, models,api
class Jewellery(models.Model):
    _name = "diamonds_rings_website.jewellery"
    _rec_name = 'name' 
    _order = "order asc"

    name = fields.Char(string="Name",required=True)
    category = fields.Many2one('diamonds_rings_website.category',string="Category")
    type = fields.Many2one('diamonds_rings_website.type',string="Type", domain="[('type_id', '=', category)]")
    sku = fields.Char(string="SKU")
    desc = fields.Text(string="Description")
    price = fields.Float(string="Price", required=True)
    discount_price = fields.Float(string="Discount Price")
    diamond_number = fields.Selection([('1', '1'), ('2', '2')], string="Number of diamond", default='1')
    metal = fields.Many2many('metal', string="Metal")
    order = fields.Integer()
    # RELATED FIELDS
    jewellery_id = fields.Many2one('diamonds_rings_website.jewellery')
    rules = fields.One2many('attribute', 'product_id', string='Rules',store=True)
    # filtered_diamond_ids = fields.Many2many('diamonds_rings_website.diamond', string="Filtered Diamonds", relation="jewellery_filtered_diamond_rel",
    #     compute='apply_rules',store=True)
    added_values = fields.One2many('added.value','jewellery_id', string="Added Values")
    image_lines = fields.One2many('image','jew_id',string="Images")
    # priority_diamond_ids = fields.Many2many('diamonds_rings_website.diamond', string="Selected Pair", relation="jewellery_priority_diamond_rel",
    #     compute='_compute_priority_diamonds', store=True)
    is_available_for_design = fields.Boolean()
    #extra info
    # setting_type = fields.Char()
    # width = fields.Char()
    # length = fields.Char()
    # clasp = fields.Char()
    # chain_type = fields.Char()
    # rodium_plated = fields.Char()
    # number_of_stones = fields.Char()
    # shape = fields.Char()
    # carat = fields.Char()
    # cut = fields.Char()
    # clarity = fields.Char()
    # color = fields.Char()



    # def get_top_diamonds(self, diamonds, limit=2):
    #     """
    #     Returns the top diamonds based on the priorities: diamond_size, cut, clarity, and color.
    #
    #     :param diamonds: Recordset of diamonds to be filtered.
    #     :param limit: The maximum number of diamonds to return (default is 2).
    #     :return: List of top diamond IDs.
    #     """
    #     sorted_diamonds = sorted(diamonds, key=lambda d: (d.diamond_size, d.cut.id, d.clarity.id, d.color.id))
    #     return sorted_diamonds[:limit]
    #
    # @api.depends('filtered_diamond_ids', 'diamond_number')
    # def _compute_priority_diamonds(self):
    #     for record in self:
    #         # Clear existing priority diamonds
    #         record.priority_diamond_ids = [(5, 0, 0)]
    #         if record.diamond_number == '2':
    #             if len(record.filtered_diamond_ids) == 1:
    #                 # If there's only one diamond, find the best match
    #                 existing_diamond = record.filtered_diamond_ids[0]
    #                 all_diamonds = self.env['diamonds_rings_website.diamond'].search([])
    #                 similar_diamonds = all_diamonds.filtered(lambda d: d.id != existing_diamond.id)
    #                 sorted_similar_diamonds = sorted(similar_diamonds, key=lambda d: (
    #                     abs(d.diamond_size - existing_diamond.diamond_size),
    #                     d.cut.id == existing_diamond.cut.id,
    #                     d.clarity.id == existing_diamond.clarity.id,
    #                     d.color.id == existing_diamond.color.id
    #                 ))
    #                 best_match = sorted_similar_diamonds[0] if sorted_similar_diamonds else None
    #                 record.priority_diamond_ids = [(5, 0, 0), (4, existing_diamond.id)]
    #                 if best_match:
    #                     record.priority_diamond_ids = [(4, existing_diamond.id), (4, best_match.id)]
    #             else:
    #                 # Get top diamonds if there are more than one
    #                 top_diamonds = record.get_top_diamonds(record.filtered_diamond_ids, limit=2)
    #                 record.priority_diamond_ids = [(5, 0, 0)]
    #                 if top_diamonds:
    #                     record.priority_diamond_ids = [(4, diamond.id) for diamond in top_diamonds]
    #         else:
    #             record.priority_diamond_ids = [(5, 0, 0)]

    def create(self, vals):
        rec = super(Jewellery, self).create(vals)
        if 'rules' in vals or 'metal' in vals:
            rec.update_images()

        if 'rules' in vals:
            rec.update_added_values()

        return rec

    def write(self, vals):
        rec = super(Jewellery, self).write(vals)
        if 'rules' in vals or 'metal' in vals:
            self.update_images()

        if 'rules' in vals:
            self.update_added_values()

        return rec

    def update_images(self):
        for jewellery in self:
            if not jewellery.metal or not any(rule.attribute_id.attribute_name == 'shape' for rule in jewellery.rules):
                # If there are no metals or no shape rules, clear image_lines
                jewellery.image_lines = [(5, 0, 0)]
                return

            current_image_type_names = set()
            selected_attribute_values = jewellery.rules.filtered(
                lambda r: r.attribute_id.attribute_name == 'shape').mapped('attribute_values')

            for metal in jewellery.metal:
                for value in selected_attribute_values:
                    image_type_name = f"{value.value_name} - {metal.metal_name}"
                    current_image_type_names.add(image_type_name)
                    shape_value = value.value_name
                    metal_value = metal.metal_name

            jewellery.image_lines.filtered(lambda line: line.image_type_name not in current_image_type_names).unlink()
            existing_image_lines = {line.image_type_name: line.id for line in jewellery.image_lines}
            # Identify image lines to add and remove
            image_lines_to_add = []
            for image_type_name in current_image_type_names:
                if image_type_name not in existing_image_lines:
                    image_lines_to_add.append((0, 0, {
                        'image_type_name': image_type_name,
                        'jew_id': jewellery.id,
                        'shape_value': image_type_name.split("-")[0].strip() ,
                        'metal_value': image_type_name.split("-")[1].strip(),
                    }))
            image_lines_to_remove = jewellery.image_lines.filtered(
                lambda line: line.image_type_name not in current_image_type_names)


            # # Unlink lines to be removed
            if image_lines_to_remove:
                image_lines_to_remove.unlink()
            #
            # Update image lines by adding new ones
            if image_lines_to_add:
                jewellery.image_lines = image_lines_to_add

    def update_added_values(self):
        if not self.rules.filtered(lambda r: r.attribute_id.attribute_name in ['shape', 'size']):
            self.added_values = [(5, 0, 0)]
            return

        values = []
        shapes = self.rules.filtered(lambda r: r.attribute_id.attribute_name == 'shape')
        sizes = self.rules.filtered(lambda r: r.attribute_id.attribute_name == 'size')

        for shape in shapes.attribute_values:
            for size in sizes.attribute_values:
                value = f"{shape.value_name} - {size.value_name}"
                values.append(value)

        #remove records related to deleted attribute values
        self.added_values.filtered(lambda val : val.value_name not in values).unlink()

        #add new records for added values
        to_add = []
        for v in values:
            if not self.added_values.filtered(lambda a: a.value_name == v):
                to_add.append((0, 0, {
                    'value_name': v,
                    'jewellery_id': self.id,
                }))
        self.added_values = to_add


        # existing_values = self.added_values.mapped('value_name')
        # values_to_add = []
        #
        # # Collect values from rules
        # for rule in self.rules:
        #     for value in rule.attribute_values:
        #         if value.value_name not in existing_values:
        #             # print('***********************************')
        #             # print(self.id)
        #             values_to_add.append((0, 0, {
        #                 'value_name': value.value_name,
        #                 'attribute_name': value.attribute_value_attribute_id.attribute_name,
        #                 'jewellery_id': self.id,
        #             }))
        #
        # # Remove values that are no longer in the rules
        # values_to_remove = self.added_values.filtered(lambda av: av.value_name not in [val.value_name for rule in self.rules for val in rule.attribute_values])
        # values_to_remove.unlink()
        #
        # # # Update added values
        # self.added_values = values_to_add

    # @api.depends('rules')
    # def apply_rules(self):
    #     print('################ ENTER THE APPLY RULES METHOD ##################')
    #     print('Clear existing filtered diamonds')
    #     self.filtered_diamond_ids = [(5, 0, 0)]
    #     print('Begin ..................')
    #     diamonds = self.env['diamonds_rings_website.diamond'].search([])
    #     filters = {}
    #     for rule in self.rules:
    #         # print(f"Applying rule: {rule.attribute_id.attribute_name}")
    #         if rule.attribute_id and rule.attribute_values:
    #             if rule.attribute_id.attribute_name in filters:
    #                 filters[rule.attribute_id.attribute_name].extend([value.value_name for value in rule.attribute_values])
    #             else:
    #                 filters[rule.attribute_id.attribute_name] = [value.value_name for value in rule.attribute_values]
    # 
    #     if filters:
    #         filtered_diamonds = diamonds
    #         for attr, vals in filters.items():
    #             filtered_diamonds = filtered_diamonds.filtered(lambda d: getattr(d, attr).value_name in vals)
    # 
    #         # print(f"Filtered diamonds count: {len(filtered_diamonds)}")
    #         self.filtered_diamond_ids = [(5, 0, 0)]
    #         if filtered_diamonds:
    #             self.filtered_diamond_ids = [(4, diamond.id) for diamond in filtered_diamonds]
    #     else:
    #         self.filtered_diamond_ids = [(5, 0, 0)]


    def serialize(self):
        serialized_metals = [metal.serialize() for metal in self.metal]
        serialized_images = [image.serialize() for image in self.image_lines]
        return {
            'name': self.name,
            'category': self.category,
            'type': self.type,
            'sku': self.sku,
            'desc': self.desc,
            'price': self.price,
            'metal': serialized_metals,
            'image_lines': serialized_images
        }   

