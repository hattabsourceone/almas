from odoo import fields, models
from ..static.variables import COUNTRY_LIST, USER_STATES
class User(models.Model):
    _inherit = 'res.users'

    status = fields.Selection(USER_STATES, string="User Status",default='under_verification')
    newsletter = fields.Boolean(string="Subscribe", default=True)
    is_api_created = fields.Boolean(string="API Created", default=False)

    billing_ids = fields.One2many('res.billing', 'user_id', string="Billing Addresses")
    shipping_ids = fields.One2many('res.shipping', 'user_id', string="Shipping Addresses")

    wishlist_ids = fields.One2many('diamonds_rings_website.wishlist', 'customer', string="Wishlist")
    compared_diamonds_ids = fields.One2many('diamonds_rings_website.compare.diamond', 'customer', string="Compared Diamonds")
    order_ids = fields.One2many('order', 'customer', string="Order Items")

    def verify_user(self):
        for user in self:
            user.status = 'verified'

    def block_user(self):
        for user in self:
            user.status = 'blocked'
