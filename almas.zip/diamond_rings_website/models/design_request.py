from odoo import fields, models
from ..static.variables import COUNTRY_LIST

class DesignRequest(models.Model):
    _name = "diamonds_rings_website.design.request"
    _rec_name = 'id'

    full_name = fields.Char(string="Full Name",required=True)
    email_address = fields.Char(string="Email Address",required=True)
    address = fields.Char(string="Address",required=True)
    mobile_number = fields.Char(string="Mobile Number",required=True)
    type = fields.Char(string="Type",required=True)
    metal = fields.Many2one('metal',string="Metal",required=True)
    country = fields.Selection(COUNTRY_LIST,string="Country",required=True)
    file = fields.Binary(string="File")
    message = fields.Text(string="Message",required=True)
