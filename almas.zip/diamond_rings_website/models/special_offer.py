from odoo import fields, models,api

class SpecialOffer(models.Model):
    _name = "special.offer"
    _rec_name = "diamond_id"

    new_price = fields.Float(string="New Price", required=True)
    new_price_display = fields.Char(string='New Price', compute='_compute_new_price_display')

    @api.depends('new_price')
    def _compute_new_price_display(self):
        for record in self:
            record.new_price_display = f"{record.new_price} $"

    diamond_id = fields.Many2one('diamonds_rings_website.diamond', string="Diamond", required=True, ondelete='cascade')
    image_file = fields.Char(related='diamond_id.image_file')
    shape = fields.Many2one('attribute.value', string="Shape", related='diamond_id.shape')
    color = fields.Many2one('attribute.value', string="Color", related='diamond_id.color')
    clarity = fields.Many2one('attribute.value', string="Clarity", related='diamond_id.clarity')
    price = fields.Float(string="Price", related='diamond_id.total_sales_price')
    symmetry = fields.Many2one('attribute.value', string="Symmetry", related='diamond_id.symmetry')
    polish = fields.Many2one('attribute.value', string="Polish", related='diamond_id.polish')
    fluorescence = fields.Many2one('attribute.value',string="Fluorescence", related='diamond_id.fluor_intensity')
    certificate = fields.Char(string="Certificate", related='diamond_id.lab')
    cut = fields.Many2one('attribute.value', string="Cut", related='diamond_id.cut')
    size_carat = fields.Float(string="Size", related='diamond_id.diamond_size')
    meas_length = fields.Float(string="Meas Length", related='diamond_id.meas_length')
    meas_width = fields.Float(string="Meas Width", related='diamond_id.meas_width')
    meas_depth = fields.Float(string="Meas Depth", related='diamond_id.meas_depth')
    depth_percent = fields.Float(string="Depth Percent", related='diamond_id.depth_percent')
    table_percent = fields.Integer(string="Table Percent", related='diamond_id.table_percent')

    def serialize(self):
        return {
            'diamond_id': self.diamond_id,
            'shape': self.shape,
            'size_carat': self.size_carat,
            'color': self.color,
            'clarity': self.clarity,
            'cut': self.cut,
            'symmetry': self.symmetry,
            'polish': self.polish,
            'fluorescence': self.fluorescence,
            'certificate': self.certificate,
            'new_price': self.new_price
        }    
