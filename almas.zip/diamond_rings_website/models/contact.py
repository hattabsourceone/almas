from odoo import fields, models

class Contact(models.Model):
    _name = "diamonds_rings_website.contact"
    _rec_name = 'id'

    full_name = fields.Char(string="Full Name", required=True)
    email_address = fields.Char(string="Email Address",required=True)
    mobile_number = fields.Char(string="Mobile Number",required=True)
    country = fields.Char(string="Country", required=True)
    message = fields.Text(string="Message", required=True)

    
