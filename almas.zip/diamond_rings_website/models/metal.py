from odoo import fields, models

class Metal(models.Model):
    _name = "metal"
    _rec_name = 'metal_name'

    metal_name = fields.Char(string="Name")
    
    def serialize(self):
        return {
            'metal_name': self.metal_name,
        }

