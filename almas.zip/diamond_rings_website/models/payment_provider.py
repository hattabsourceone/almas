from odoo import models

class PayPro(models.Model):
    _inherit = 'payment.provider'

