from odoo import fields, models

class Email(models.Model):
    _name = "email"
    _rec_name = 'name'

    name = fields.Char(string="Email")


