from odoo import fields, models,api

class AddedValue(models.Model):
    _name = "added.value"
    _description = "Added Values Records"
    _rec_name = 'jewellery_id'
    _order = 'order asc'

    jewellery_id = fields.Many2one('diamonds_rings_website.jewellery', string="Jewellery")
    value_name = fields.Char(string="Value", store=True)
    attribute_name = fields.Char(string="Attribute",store=True)
    price = fields.Float(string="Price")
    setting_type = fields.Char()
    width = fields.Char()
    rodium_plated = fields.Char()
    number_of_stones = fields.Char()
    shape = fields.Char()
    carat = fields.Char()
    cut = fields.Char()
    clarity = fields.Char()
    color = fields.Char()
    order = fields.Integer()
    new_price = fields.Float("Discount price")
    length = fields.Char()
    clasp = fields.Char()
    chain_type = fields.Char()

    def serialize(self):
        return {
            'price': self.price
        }
    
