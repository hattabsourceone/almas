from odoo import fields, models
class Image(models.Model):
    _name = "image"
    _rec_name = 'id'
    _order = "order asc"

    image_type_name = fields.Char(string="Image Type",store=True)
    shape_value = fields.Char(string="Shape Value",store=True)
    metal_value = fields.Char(string="Metal Value",store=True)
    image_file = fields.Many2many('ir.attachment', string="Related Images")
    video_file = fields.Binary(string="Video",attachement=True)
    video_file_attachment_id = fields.Many2one('ir.attachment')
    jew_id = fields.Many2one('diamonds_rings_website.jewellery',string="ID")
    order = fields.Integer()

    def _create_attachment(self):
        """Create an attachment from the binary field content."""
        if self.video_file:
            base_url = self.env['ir.config_parameter'].sudo().search([('key', '=', 'web.base.url')], limit=1).value
            attachment = self.env['ir.attachment'].create({
                'name': f"{self.image_type_name or 'Attachment'}",
                'type': 'binary',
                'datas': self.video_file,  # Content of the binary field
                'res_model': self._name,  # Link the attachment to the model
                'res_id': self.id,  # Link to the specific record
            })
            attachment.public = True
            attachment.sudo().url = base_url + "/web/content/ir.attachment/{0}/datas".format(attachment.id)
            self.video_file_attachment_id = attachment.id

    def create(self, vals):
        record = super(Image, self).create(vals)
        if 'video_file' in vals:
            self._create_attachment()
        return record

    def write(self, vals):
        res = super(Image, self).write(vals)
        if 'video_file' in vals:
            self._create_attachment()
        return res

    def serialize(self):
        return {
            'image_type_name': self.image_type_name,
            'video_file': self.video_file,
            'image_file': self.image_file,
            'shape_value': self.shape_value,
            'metal_value': self.metal_value,
        }



