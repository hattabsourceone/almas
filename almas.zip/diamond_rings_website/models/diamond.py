from datetime import timedelta

from odoo import fields, models, api
from odoo.tools.safe_eval import datetime
from ..static.variables import ALL_ATTRIBUTES, ATTRIBUTES, color_values, clarity_values, cut_values
import requests
import json
import math
import pandas as pd

UPDATE_TIME = None
ALL_DIAMONDS = []


class Diamond(models.Model):
    _name = "diamonds_rings_website.diamond"
    _rec_name = 'diamond_id'
    _order = "diamond_size asc, color_order asc, cut_order asc, clarity_order asc"

    diamond_id = fields.Integer(string="Diamond ID", unique=True, index=True)
    shape = fields.Many2one('attribute.value', string="Shape",
                            domain="[('attribute_value_attribute_id.attribute_name', '=', 'shape')]")
    diamond_size = fields.Float(string="Size", compute="_compute_diamond_size", store=True, index=True)
    size = fields.Many2one('attribute.value', string="Size",
                            domain="[('attribute_value_attribute_id.attribute_name', '=', 'size')]")
    color = fields.Many2one('attribute.value', string="Color",
                            domain="[('attribute_value_attribute_id.attribute_name', '=', 'color')]")
    clarity = fields.Many2one('attribute.value', string="Clarity",
                              domain="[('attribute_value_attribute_id.attribute_name', '=', 'clarity')]")
    fancy_color_dominant_color = fields.Many2one('attribute.value', string="Fancy Dominant",
                                                 domain="[('attribute_value_attribute_id.attribute_name', '=', 'fancy_color_dominant_color')]")
    fancy_color_secondary_color = fields.Many2one('attribute.value', string="Fancy Secondary",
                                                  domain="[('attribute_value_attribute_id.attribute_name', '=', 'fancy_color_secondary_color')]")
    fancy_color_overtone = fields.Many2one('attribute.value', string="Fancy Overtone",
                                           domain="[('attribute_value_attribute_id.attribute_name', '=', 'fancy_color_overtone')]")
    fancy_color_intensity = fields.Many2one('attribute.value', string="Fancy Intentsity",
                                            domain="[('attribute_value_attribute_id.attribute_name', '=', 'fancy_color_intensity')]")
    cut = fields.Many2one('attribute.value', string="Cut",
                          domain="[('attribute_value_attribute_id.attribute_name', '=', 'cut')]")
    symmetry = fields.Many2one('attribute.value', string="Symmetry",
                               domain="[('attribute_value_attribute_id.attribute_name', '=', 'symmetry')]")
    polish = fields.Many2one('attribute.value', string="PoliSymmetrysh",
                             domain="[('attribute_value_attribute_id.attribute_name', '=', 'polish')]")
    depth_percent = fields.Float(string="Depth Percent")
    table_percent = fields.Integer(string="Table Percent")
    meas_length = fields.Float(string="Meas Length")
    meas_width = fields.Float(string="Meas Width")
    meas_depth = fields.Float(string="Meas Depth")
    girdle_min = fields.Many2one('attribute.value', string="Girdle Min",
                                 domain="[('attribute_value_attribute_id.attribute_name', '=', 'girdle_min')]")
    girdle_max = fields.Many2one('attribute.value', string="Girdle Max",
                                 domain="[('attribute_value_attribute_id.attribute_name', '=', 'girdle_max')]")
    girdle_condition = fields.Char(string="Girdle Condition")
    culet_size = fields.Many2one('attribute.value', string="Culet Size",
                                 domain="[('attribute_value_attribute_id.attribute_name', '=', 'culet_size')]")
    culet_condition = fields.Char(string="Culet Condition")
    fluor_color = fields.Many2one('attribute.value', string="Fluor Color",
                                  domain="[('attribute_value_attribute_id.attribute_name', '=', 'fluor_color')]")
    fluor_intensity = fields.Many2one('attribute.value', string="Fluro Intensity",
                                      domain="[('attribute_value_attribute_id.attribute_name', '=', 'fluor_intensity')]")
    has_cert_file = fields.Integer(string="Has Cert File")
    lab = fields.Char(string="Lab")
    currency_code = fields.Char(string="Currency Code")
    currency_symbole = fields.Char(string="Currency Symbole")
    cert_num_diamond = fields.Char(string="Cert Number")
    stock_num = fields.Char(string="Stock Numero")
    video_url = fields.Char(attachement=True)
    has_video = fields.Integer(string="Has Video")
    eye_clean_diamond = fields.Char(string="Eye Clean")
    has_image_file = fields.Integer(string="Has Image File")
    has_sarineloupe = fields.Integer(string="Has Sarineloupe")
    image_file = fields.Char(string="Image File")
    total_sales_price = fields.Float(string="Total Sales Price", index=True)
    total_sales_price_in_currency = fields.Integer(string="Total Sales Price In Currency")
    total_sales_price_display = fields.Char(string='Total Sales Price Display',
                                            compute='_compute_total_sales_price_display')
    ratio = fields.Char(string="Ratio")
    is_bgm = fields.Integer(string="Is BGM")

    # RELATED FIELDS
    product_id = fields.Many2one('diamonds_rings_website.diamond')
    latest_update = fields.Datetime("Latest Update", )
    active = fields.Boolean(default=True)

    #Order fields
    color_order = fields.Integer(compute="_compute_color_order", store=True, index=True )
    cut_order = fields.Integer(compute="_compute_cut_order", store=True, index=True )
    clarity_order = fields.Integer(compute="_compute_clarity_order",store=True, index=True )

    def recompute_data(self):
        model = self.env['diamonds_rings_website.diamond']
        self.env.add_to_compute(model._fields['clarity_order'], model.search([]))
        model._recompute_recordset()

    @api.depends('total_sales_price')
    def _compute_total_sales_price_display(self):
        for record in self:
            record.total_sales_price_display = f"{record.total_sales_price} $"

    @api.depends('size')
    def _compute_diamond_size(self):
        for _rec in self:
            try:
                _rec.diamond_size = float(_rec.size.value_name)
            except:
                _rec.diamond_size = 0.0

    @api.depends('color')
    def _compute_color_order(self):
        for _rec in self:
            _rec.color_order = color_values.get(_rec.color.value_name, 99) if _rec.color else 99

    @api.depends('cut')
    def _compute_cut_order(self):
        for _rec in self:
            _rec.cut_order = cut_values.get(_rec.cut.value_name, 99) if _rec.cut else 99

    @api.depends('clarity')
    def _compute_clarity_order(self):
        for _rec in self:
            _rec.clarity_order = clarity_values.get(_rec.clarity.value_name, 99) if _rec.clarity else 99

    def put_to_special_offer(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Choose the New Price',
            'res_model': 'add.special.offer',
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'new',
            'context': {'default_diamond_id': self.id}
        }

    def serialize(self):
        return {
            'diamond_id': self.diamond_id,
            'shape': self.shape,
            'diamond_size': self.diamond_size,
            'color': self.color,
            'clarity': self.clarity,
            'fancy_color_dominant_color': self.fancy_color_dominant_color,
            'fancy_color_secondary_color': self.fancy_color_secondary_color,
            'fancy_color_overtone': self.fancy_color_overtone,
            'fancy_color_intensity': self.fancy_color_intensity,
            'cut': self.cut,
            'symmetry': self.symmetry,
            'polish': self.polish,
            'depth_percent': self.depth_percent,
            'table_percent': self.table_percent,
            'meas_length': self.meas_length,
            'meas_width': self.meas_width,
            'meas_depth': self.meas_depth,
            'girdle_min': self.girdle_min,
            'girdle_max': self.girdle_max,
            'girdle_condition': self.girdle_condition,
            'culet_size': self.culet_size,
            'culet_condition': self.culet_condition,
            'fluor_color': self.fluor_color,
            'fluor_intensity': self.fluor_intensity,
            'has_cert_file': self.has_cert_file,
            'lab': self.lab,
            'currency_code': self.currency_code,
            'currency_symbole': self.currency_symbole,
            'cert_num_diamond': self.cert_num_diamond,
            'stock_num': self.stock_num,
            'video_url': self.video_url,
            'has_video': self.has_video,
            'eye_clean_diamond': self.eye_clean_diamond,
            'has_image_file': self.has_image_file,
            'has_sarineloupe': self.has_sarineloupe,
            'image_file': self.image_file,
            'total_sales_price': self.total_sales_price,
            'total_sales_price_in_currency': self.total_sales_price_in_currency,
            'total_sales_price_display': self.total_sales_price_display,
            'ratio': self.ratio,
            'is_bgm': self.is_bgm,
        }

    def load_initial_data(self):
        global UPDATE_TIME
        UPDATE_TIME = fields.Datetime.now()
        global ALL_DIAMONDS
        ALL_DIAMONDS = []
        # self.delete_data()
        # Delete all existing records
        print("Starting initial data load ...................")
        # Call the API to get diamond data
        api_response = self.get_diamonds(1)
        if 'response' in api_response and 'body' in api_response['response'] and 'diamonds' in api_response['response'][
            'body']:
            total_diamonds = api_response['response']['body']['search_results']['total_diamonds_found']
            diamonds_returned = api_response['response']['body']['search_results']['diamonds_returned']
            total_pages = math.ceil(total_diamonds / diamonds_returned)
            pages_to_insert = math.ceil(total_diamonds / 1000)

            for pg in range(1, total_pages + 1):
                api_response = self.get_diamonds(pg)
                if 'response' in api_response and 'body' in api_response['response'] and 'diamonds' in api_response['response'][
                    'body']:
                    ALL_DIAMONDS += api_response['response']['body']['diamonds']
            for page in range(1, pages_to_insert + 1):
                self._process_page(page)
                self.env.cr.commit()
            # newly added by suggestion  of ihab
            self.remove_outdated_products()
            # ------------------

    def remove_outdated_products(self):
        current_time = fields.Datetime.now()
        time_threshold = current_time - timedelta(minutes=120)
        products_to_remove = self.env['diamonds_rings_website.diamond'].search(['|', ('latest_update', '<', time_threshold), ('latest_update', '=', False)])
        if products_to_remove:
            products_to_remove.unlink()

    # def _process_page(self, page):
    #     print(f"Processing page {page}...")
    #
    #     api_response = self.get_diamonds(page)
    #     if 'response' in api_response and 'body' in api_response['response'] and 'diamonds' in api_response['response']['body']:
    #         diamonds = api_response['response']['body']['diamonds']
    #         for diamond in diamonds:
    #             self._process_diamond(diamond)

    def _process_page(self, page):
        first_index = (page * 1000) - 1000
        last_index = (page * 1000 )
        # api_response = self.get_diamonds(page)
        # if 'response' in api_response and 'body' in api_response['response'] and 'diamonds' in api_response['response'][
        #     'body']:
        if ALL_DIAMONDS:
            diamonds = ALL_DIAMONDS[first_index:last_index]
            # diamonds = api_response['response']['body']['diamonds']
            # for diamond in diamonds:
            #    self._process_diamond(diamond)
            # this part should be refactored
            diamond_ids = [rec['diamond_id'] for rec in diamonds]
            existing_records = self.search([('diamond_id', 'in', diamond_ids)])
            new_records = []
            update_records = []
            existing_map = {rec.diamond_id: rec for rec in existing_records}
            for data in diamonds:
                external_id = data['diamond_id']
                price = data['total_sales_price']
                self._process_diamond(data)

                if external_id in existing_map:
                    existing_record = existing_map[external_id]
                    update_records.append(
                        (existing_record.id, {'total_sales_price': price, 'latest_update': UPDATE_TIME, }))

                else:
                    new_records.append({
                        'diamond_id': data['diamond_id'],
                        'shape': self._get_attribute_value_id('shape', data['shape']),
                        'size': self._get_attribute_value_id('size', str(data['size'])),
                        'color': self._get_attribute_value_id('color', data['color']),
                        'clarity': self._get_attribute_value_id('clarity', data['clarity']),
                        'fancy_color_dominant_color': self._get_attribute_value_id('fancy_color_dominant_color',
                                                                                   data['fancy_color_dominant_color']),
                        'fancy_color_secondary_color': self._get_attribute_value_id('fancy_color_secondary_color', data[
                            'fancy_color_secondary_color']),
                        'fancy_color_overtone': self._get_attribute_value_id('fancy_color_overtone',
                                                                             data['fancy_color_overtone']),
                        'fancy_color_intensity': self._get_attribute_value_id('fancy_color_intensity',
                                                                              data['fancy_color_intensity']),
                        'cut': self._get_attribute_value_id('cut', data['cut']),
                        'symmetry': self._get_attribute_value_id('symmetry', data['symmetry']),
                        'polish': self._get_attribute_value_id('polish', data['polish']),
                        'depth_percent': float(data['depth_percent']),
                        'table_percent': float(data['table_percent']),
                        'meas_length': float(data['meas_length']),
                        'meas_width': float(data['meas_width']),
                        'meas_depth': float(data['meas_depth']),
                        'girdle_min': self._get_attribute_value_id('girdle_min', data['girdle_min']),
                        'girdle_max': self._get_attribute_value_id('girdle_max', data['girdle_max']),
                        'girdle_condition': data['girdle_condition'],
                        'culet_size': self._get_attribute_value_id('culet_size', data['culet_size']),
                        'culet_condition': data['culet_condition'],
                        'fluor_color': self._get_attribute_value_id('fluor_color', data['fluor_color']),
                        'fluor_intensity': self._get_attribute_value_id('fluor_intensity', data['fluor_intensity']),
                        'has_cert_file': data['has_cert_file'],
                        'lab': data['lab'],
                        'currency_code': data['currency_code'],
                        'currency_symbole': data['currency_symbol'],
                        'cert_num_diamond': data['cert_num'],
                        'stock_num': data['stock_num'],
                        'video_url': data['video_url'],
                        'has_video': int(data['has_video']),
                        'eye_clean_diamond': data['eye_clean'],
                        'has_image_file': int(data['has_image_file']),
                        'has_sarineloupe': int(data['has_sarineloupe']),
                        'image_file': data['image_file'],
                        'total_sales_price': float(data['total_sales_price']),
                        'total_sales_price_in_currency': data['total_sales_price_in_currency'],
                        'total_sales_price_display': f"{data['total_sales_price']} $",
                        'ratio': data['ratio'],
                        'is_bgm': int(data['is_bgm']),
                        'latest_update': UPDATE_TIME,
                    })

            if new_records:
                self.create(new_records)

            if update_records:
                for rec_id, vals in update_records:
                    self.browse(rec_id).write(vals)

    def _process_diamond(self, diamond):
        for attribute_name in ALL_ATTRIBUTES:
            if attribute_name in ATTRIBUTES:
                attribute = self.env['attribute'].search([('attribute_name', '=', attribute_name)])
                if not attribute:
                    attribute = self.env['attribute'].create({'attribute_name': attribute_name})

                value = diamond.get(attribute_name, '').strip() if diamond.get(attribute_name,
                                                                               '') is str else diamond.get(
                    attribute_name, '')
                if value:
                    existing_value = self.env['attribute.value'].search(
                        [('value_name', '=', value), ('attribute_value_attribute_id', '=', attribute.id)], limit=1)
                    if not existing_value:
                        self.env['attribute.value'].create(
                            {'value_name': value, 'attribute_value_attribute_id': attribute.id})
                    else:
                        attribute.attribute_values += existing_value

        # Create the diamond record
        # self.create({
        #     'diamond_id': diamond['diamond_id'],
        #     'shape': self._get_attribute_value_id('shape', diamond['shape']),
        #     'diamond_size': float(diamond['size']),
        #     'color': self._get_attribute_value_id('color', diamond['color']),
        #     'clarity': self._get_attribute_value_id('clarity', diamond['clarity']),
        #     'fancy_color_dominant_color': self._get_attribute_value_id('fancy_color_dominant_color', diamond['fancy_color_dominant_color']),
        #     'fancy_color_secondary_color': self._get_attribute_value_id('fancy_color_secondary_color', diamond['fancy_color_secondary_color']),
        #     'fancy_color_overtone': self._get_attribute_value_id('fancy_color_overtone', diamond['fancy_color_overtone']),
        #     'fancy_color_intensity': self._get_attribute_value_id('fancy_color_intensity', diamond['fancy_color_intensity']),
        #     'cut': self._get_attribute_value_id('cut', diamond['cut']),
        #     'symmetry': self._get_attribute_value_id('symmetry', diamond['symmetry']),
        #     'polish': self._get_attribute_value_id('polish', diamond['polish']),
        #     'depth_percent': float(diamond['depth_percent']),
        #     'table_percent': float(diamond['table_percent']),
        #     'meas_length':float(diamond['meas_length']),
        #     'meas_width': float(diamond['meas_width']),
        #     'meas_depth': float(diamond['meas_depth']),
        #     'girdle_min': self._get_attribute_value_id('girdle_min', diamond['girdle_min']),
        #     'girdle_max': self._get_attribute_value_id('girdle_max', diamond['girdle_max']),
        #     'girdle_condition': diamond['girdle_condition'],
        #     'culet_size': self._get_attribute_value_id('culet_size', diamond['culet_size']),
        #     'culet_condition': diamond['culet_condition'],
        #     'fluor_color': self._get_attribute_value_id('fluor_color', diamond['fluor_color']),
        #     'fluor_intensity': self._get_attribute_value_id('fluor_intensity', diamond['fluor_intensity']),
        #     'has_cert_file': diamond['has_cert_file'],
        #     'lab': diamond['lab'],
        #     'currency_code': diamond['currency_code'],
        #     'currency_symbole': diamond['currency_symbol'],
        #     'cert_num_diamond': diamond['cert_num'],
        #     'stock_num': diamond['stock_num'],
        #     'video_url': diamond['video_url'],
        #     'has_video': int(diamond['has_video']),
        #     'eye_clean_diamond': diamond['eye_clean'],
        #     'has_image_file': int(diamond['has_image_file']),
        #     'has_sarineloupe':int(diamond['has_sarineloupe']),
        #     'image_file': diamond['image_file'],
        #     'total_sales_price': float(diamond['total_sales_price']),
        #     'total_sales_price_in_currency': diamond['total_sales_price_in_currency'],
        #     'total_sales_price_display': f"{diamond['total_sales_price']} $",
        #     'ratio': diamond['ratio'],
        #     'is_bgm': int(diamond['is_bgm']),
        # })

    def _get_attribute_value_id(self, attribute_name, value):
        if not value:
            return False
        attribute = self.env['attribute'].search([('attribute_name', '=', attribute_name)], limit=1)
        if attribute:
            attribute_value = self.env['attribute.value'].search([
                ('attribute_value_attribute_id', '=', attribute.id),
                ('value_name', '=', value.strip())
            ], limit=1)
            if attribute_value:
                return attribute_value.id
        return False

    def get_diamonds(self, page):
        url = 'http://technet.rapaport.com/HTTP/JSON/RetailFeed/GetDiamonds.aspx'
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}

        payload = {
            "request": {
                "header": {
                    "username": "bgp9ahprsrimeugkpzug82fbf0uh1a",
                    "password": "g6zthpid"
                },
                "body": {
                    "sort_by": "Price",
                    "sort_direction": "Asc",
                    "page_number": page,
                    "page_size": 200000,
                }
            }
        }

        response = requests.post(url, headers=headers, data=json.dumps(payload))
        if response.status_code == 200:
            return response.json()
        else:
            return {"error": f"Request failed with status code {response.status_code}"}

    def write_response(self):
        url = "http://technet.rapaport.com/HTTP/JSON/RetailFeed/GetDiamonds.aspx"

        payload = '{"request": {"header": {"username": "bgp9ahprsrimeugkpzug82fbf0uh1a","password": "g6zthpid"},"body": {"search_type": "White","page_number": "1","page_size": "200000"}}}'
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
        }

        response = requests.request("POST", url, headers=headers, data=payload)

        # save to excel
        json_data = json.loads(response.text)
        df = pd.DataFrame(json_data['response']['body']['diamonds'])
        df.to_excel('/home/omar/Desktop/excel2.xlsx', index=False)

        # save to csv
        # print(response.text)
        # json_data = json.loads(response.text)
        # df = pd.DataFrame(json_data['response']['body']['diamonds'])
        # df.to_csv('/home/omar/Desktop/secondcsv.csv', index=False)
        # print(json_data['response']['body']['diamonds'])

    def find_diff(self):
        # Load the two Excel files into pandas DataFrames
        df1 = pd.read_excel('/home/omar/Desktop/excel1.xlsx')
        df2 = pd.read_excel('/home/omar/Desktop/excel1.xlsx')

        # Set the key_column as the index for easy comparison
        df1.set_index("diamond_id", inplace=True)
        df2.set_index("diamond_id", inplace=True)

        # Handle NaN values by filling them with a common placeholder
        df1.fillna(value=0, inplace=True)
        df2.fillna(value=0, inplace=True)

        # Identify added rows (rows in df2 but not in df1)
        added = df2[~df2.index.isin(df1.index)]
        # added.to_excel("/home/omar/Desktop/added.xlsx")
        # Identify deleted rows (rows in df1 but not in df2)
        deleted = df1[~df1.index.isin(df2.index)]
        # deleted.to_excel("/home/omar/Desktop/deleted.xlsx")
        # Identify updated rows (rows where the key exists in both, but values are different)
        common_keys = df1.index.intersection(df2.index)
        print("1")
        print(common_keys)
        print(2)
        print(df1.loc[common_keys])
        print(3)
        print(df2.loc[common_keys])
        print(4)
        print(df1.loc[common_keys] != df2.loc[common_keys])
        updated = df1.loc[common_keys] != df2.loc[common_keys]
        print(5)
        print(updated)
        updated_rows = df2.loc[updated.any(axis=1)]
        updated_rows.to_excel("/home/omar/Desktop/updated.xlsx")

        # second try
        # df1 = pd.read_csv('/home/omar/Desktop/secondcsv.csv')
        # df2 = pd.read_csv('/home/omar/Desktop/csvfile1.csv')

        # Set the key_column as the index for easy comparison
        # df1.set_index('diamond_id', inplace=True)
        # df2.set_index("diamond_id", inplace=True)

        # Identify added rows (rows in df2 but not in df1)
        # added = df2[~df2.index.isin(df1.index)]

        # Identify deleted rows (rows in df1 but not in df2)
        # deleted = df1[~df1.index.isin(df2.index)]

        # Identify updated rows (rows where the key exists in both, but values are different)
        # common_keys = df1.index.intersection(df2.index)
        # updated = df1.loc[common_keys] != df2.loc[common_keys]
        # updated_rows = df2.loc[:,updated.notnull().any(axis=0)]  # Rows with actual changes
        #
        # print("added record")
        # print(added)
        # print(type(added))
        # print(added.to_dict())
        # print(updated_rows.to_dict())
        # for added_record in added:
        #     print(added_record)
        #
        # print("deleted record")
        # print(deleted)
        # for deleted_record in deleted:
        #     print(deleted_record)
        #
        # print("updated record")
        # print(type(updated_rows))
        # for updated_record in updated_rows:
        #     print(updated_record )
        # print( added, deleted, updated_rows)

        # first try
        # # Read the CSV files into DataFrames
        # df1 = pd.read_csv('/home/omar/Desktop/secondcsv.csv')
        # df2 = pd.read_csv('/home/omar/Desktop/csvfile.csv')
        #
        # # print(df1.index.difference(df2.index))
        # print(df1.reindex_like(df2).compare(df2))
        # # Compare the DataFrames
        # # diff = df1.compare(df2)
        #
        # # Print the differences
        # print("Differences between file1 and file2:")
        # # print(diff)
        #
