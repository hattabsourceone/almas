from . import diamond,category,contact,jewellery,attribute,design_request, order,user,added_value,metal
from . import image,question, wishlist, compare_diamonds, special_offer
from . import cart,shipping,billing
from . import payment_provider, attachment, email