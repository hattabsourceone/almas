from odoo import fields, models,api

class AttributeValue(models.Model):
    _name = "attribute.value"
    _description = "Attribute Value Records"
    _rec_name = 'value_name'

    attribute_value_id = fields.Many2one('attribute.value', string="Attribut")
    value_name = fields.Char(string='Value', required=True,store=True)
    attribute_value_attribute_id = fields.Many2one('attribute', string='Attribut')

    def serialize(self):
        return {
            'value_name': self.value_name,
        }

class Attribute(models.Model):
    _name = "attribute"
    _description = "Attribute Records"
    _rec_name = 'attribute_name'

    attribute_name = fields.Char(string='Attribute')
    attribute_values = fields.Many2many('attribute.value', 'attribute_value_attribute_id', string='Values',required=True)
    attribute_id = fields.Many2one('attribute', string='Attribute')
    product_id = fields.Many2one('diamonds_rings_website.jewellery', string="Jewellery")
    
    def serialize(self):
        return {
            'attribute_name': self.attribute_name,
        }


