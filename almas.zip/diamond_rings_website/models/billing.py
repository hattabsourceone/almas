from odoo import fields, models

class Billing(models.Model):
    _name = 'res.billing'
    _rec_name = 'full_name'
    _description = 'Billing Address'

    full_name = fields.Char(string="Full Name")
    mobile_w_country = fields.Char(string="Mobile with Country code")
    address = fields.Char(string="Address")
    address_2 = fields.Char(string="Address 2")
    company = fields.Char()
    city = fields.Char(string="City")
    post_code = fields.Char(string="Post Code")
    country = fields.Char(string="Country")
    state = fields.Char(string="State")
    is_default = fields.Boolean()
    
    user_id = fields.Many2one('res.users', string="User")

    def serialize(self):
        return {
            'full_name': self.full_name,
            'mobile_w_country': self.mobile_w_country,
            'address': self.address,
            'address_2': self.address_2,
            'company': self.company,
            'city': self.city,
            'post_code': self.post_code,
            'country': self.country,
        }