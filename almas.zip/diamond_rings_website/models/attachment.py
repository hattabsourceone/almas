from odoo import models


class Attachment(models.Model):
    _inherit = 'ir.attachment'

    def create(self, vals):
        res = super(Attachment, self).create(vals)
        base_url = self.env['ir.config_parameter'].sudo().search([('key', '=', 'web.base.url')], limit=1).value
        if res.res_model == 'image':
            res.public = True
            res.sudo().url = base_url + "/web/content/ir.attachment/{0}/datas".format(res.id)

        return res