# order.purchase_date.strftime('%Y-%m-%d')

from odoo import fields, models, api
from ..static.variables import ORDER_STATES
from odoo.addons.payment import utils as payment_utils
from werkzeug import urls


class Order(models.Model):
    _name = "order"
    _rec_name = 'id'

    purchase_date = fields.Datetime(string="Purchase Date")
    cardholder_name = fields.Char(string="Cardholder name")
    card_number = fields.Char(string="Card Number")
    expiration_date = fields.Char(string="Expiration Date")
    security_code = fields.Char(string="Security code")
    status = fields.Selection(ORDER_STATES, string="Status", default='order_placed')
    link = fields.Char(string="Payment Link", compute='_compute_link')
    payment_intent = fields.Char()

    shipping_address = fields.Many2one('res.shipping', string="Shipping Address")
    billing_address = fields.Many2one('res.billing', string="Billing Address")
    amount = fields.Float(string="Total Amount", required=True)
    subtotal = fields.Float()

    notes = fields.Char()
    # RELATED FIELDS 
    customer = fields.Many2one('res.users', string="Customer")
    jewellery_ids = fields.Many2many('cart.jewellery', string="Product Jewellery")
    # jewellery_ids = fields.Many2many('diamonds_rings_website.jewellery', string="Product Jewellery")
    diamond_ids = fields.Many2many('diamonds_rings_website.diamond', string="Product Diamond")
    diamond_history_ids = fields.One2many('order.history', 'order_id', compute="_compute_history", store=True)
    shipment_number = fields.Char()
    tracking_link = fields.Char()
    courier_company = fields.Char()
    deliver_on = fields.Date()

    def set_to_refused(self):
        template = self.env.ref('diamond_rings_website.email_order_refused_template')
        template.send_mail(self, force_send=True)
        self.status = 'refused'

    def set_to_under_process(self):
        template = self.env.ref('diamond_rings_website.email_order_under_process_template')
        template.send_mail(self, force_send=True)
        self.status = 'under_process'

    def set_to_shipped(self):
        template = self.env.ref('diamond_rings_website.email_order_shipped_template')
        template.send_mail(self, force_send=True)
        self.status = 'shipped'

    def set_to_delivered(self):
        template = self.env.ref('diamond_rings_website.email_order_delivered_template')
        template.send_mail(self, force_send=True)
        self.status = 'delivered'

    def set_to_return_request(self):
        template = self.env.ref('diamond_rings_website.email_order_return_request_template')
        template.send_mail(self, force_send=True)
        self.status = 'return_request'

    def set_to_return_received(self):
        template = self.env.ref('diamond_rings_website.email_order_return_received_template')
        template.send_mail(self, force_send=True)
        self.status = 'return_received'

    def set_to_returned(self):
        template = self.env.ref('diamond_rings_website.email_order_return_complete_template')
        template.send_mail(self, force_send=True)
        self.status = 'returned'

    def set_to_canceled(self):
        template = self.env.ref('diamond_rings_website.email_order_canceled_template')
        template.send_mail(self, force_send=True)
        self.status = 'canceled'

    @api.depends('diamond_ids')
    def _compute_history(self):
        for _rec in self:
            for diamond in _rec.diamond_ids:
                diamond_in_offer_ids = self.env['special.offer'].sudo().search(
                    [('diamond_id', '=', diamond.id)])

                _rec.diamond_history_ids = [
                    (0, 0, {"diamond_id": diamond.diamond_id, 'diamond_size': diamond.diamond_size,
                            'shape': diamond.shape.serialize()['value_name'],
                            'cut': diamond.cut.serialize()['value_name'],
                            'color': diamond.color.serialize()['value_name'],
                            'clarity': diamond.clarity.serialize()['value_name'],
                            'polish': diamond.polish.serialize()['value_name'],
                            'symmetry': diamond.symmetry.serialize()['value_name'],
                            'fluor_intensity': diamond.fluor_intensity.serialize()['value_name'],
                            'lab': diamond.lab,
                            'stock_num': diamond.stock_num,
                            'total_sales_price':diamond_in_offer_ids.new_price if diamond_in_offer_ids  else diamond.total_sales_price})]

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        if 'link' in fields_list:
            res['link'] = ''
        return res

    def _get_access_token(self):
        self.ensure_one()
        return payment_utils.generate_access_token(
            self.customer.id if self.customer else 0, self.amount
        )

    @api.depends('amount', 'customer')
    def _compute_link(self):
        for record in self:
            related_document = record
            if not related_document.exists():
                base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            else:
                base_url = related_document.get_base_url()

            url_params = {
                'amount': record.amount,
                'access_token': record._get_access_token(),
                'order_id': record.id,
                **record._get_additional_link_values(),
            }
            record.link = f'{base_url}/payment/pay?{urls.url_encode(url_params)}'

    def _get_additional_link_values(self):
        self.ensure_one()
        return {
            'amount': self.amount,
        }


class OrderHistory(models.Model):
    _name = "order.history"

    order_id = fields.Many2one('order')
    diamond_id = fields.Char()
    diamond_size = fields.Char()
    shape = fields.Char()
    cut = fields.Char()
    color = fields.Char()
    clarity = fields.Char()
    polish = fields.Char()
    symmetry = fields.Char()
    fluor_intensity = fields.Char()
    lab = fields.Char()
    stock_num = fields.Char()
    total_sales_price = fields.Float()
