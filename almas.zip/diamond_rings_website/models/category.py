from odoo import fields, models

class Category(models.Model):
    _name = "diamonds_rings_website.category"
    _rec_name = 'category_name'

    catgeory_image = fields.Binary(attachement=True)
    category_name = fields.Char(string="Name")
    category_desc = fields.Text(string="Description")
    category_type_name_lines= fields.One2many('diamonds_rings_website.type', inverse_name='type_id')
    image_url = fields.Char()

    def _create_attachment(self):
        """Create an attachment from the binary field content."""
        if self.catgeory_image:
            base_url = self.env['ir.config_parameter'].sudo().search([('key', '=', 'web.base.url')], limit=1).value
            attachment = self.env['ir.attachment'].create({
                'name': f"{self.category_name or 'Attachment'}",
                'type': 'binary',
                'datas': self.catgeory_image,  # Content of the binary field
                'res_model': self._name,  # Link the attachment to the model
                'res_id': self.id,  # Link to the specific record
            })
            attachment.public = True
            attachment.sudo().url = base_url + "/web/content/ir.attachment/{0}/datas".format(attachment.id)
            self.image_url = attachment.sudo().url

    def create(self, vals):
        record = super(Category, self).create(vals)
        if 'catgeory_image' in vals:
            self._create_attachment()

        return record

    def write(self, vals):
        res = super(Category, self).write(vals)
        if 'catgeory_image' in vals:
            self._create_attachment()

        return res

    def serialize(self):
        serialized_types = [category_type.serialize() for category_type in self.category_type_name_lines]
        return {
            'category_name': self.category_name,
            'category_desc': self.category_desc,
            'types': serialized_types,
            'catgeory_image': self.catgeory_image
        }
class Type(models.Model):
    _name = "diamonds_rings_website.type"
    _rec_name = 'type_name'

    type_name = fields.Char(string="Name")
    type_image_small = fields.Binary(string="The Small Image")
    type_image_large = fields.Binary(string="The Large Image")
    type_id = fields.Many2one('diamonds_rings_website.category')
    image_url = fields.Char()
    large_image_url = fields.Char()

    def _create_attachment(self):
        """Create an attachment from the binary field content."""
        if self.type_image_small:
            base_url = self.env['ir.config_parameter'].sudo().search([('key', '=', 'web.base.url')], limit=1).value
            attachment = self.env['ir.attachment'].create({
                'name': f"{self.type_name or 'Attachment'}",
                'type': 'binary',
                'datas': self.type_image_small,  # Content of the binary field
                'res_model': self._name,  # Link the attachment to the model
                'res_id': self.id,  # Link to the specific record
            })
            attachment.public = True
            attachment.sudo().url = base_url + "/web/content/ir.attachment/{0}/datas".format(attachment.id)
            self.image_url = attachment.sudo().url

    def _create_large_attachment(self):
        """Create an attachment from the binary field content."""
        if self.type_image_large:
            base_url = self.env['ir.config_parameter'].sudo().search([('key', '=', 'web.base.url')], limit=1).value
            attachment = self.env['ir.attachment'].create({
                'name': f"{self.type_name or 'Attachment'}",
                'type': 'binary',
                'datas': self.type_image_large,  # Content of the binary field
                'res_model': self._name,  # Link the attachment to the model
                'res_id': self.id,  # Link to the specific record
            })
            attachment.public = True
            attachment.sudo().url = base_url + "/web/content/ir.attachment/{0}/datas".format(attachment.id)
            self.large_image_url = attachment.sudo().url

    def create(self, vals):
        record = super(Type, self).create(vals)
        if 'type_image_small' in vals:
            self._create_attachment()

        if 'type_image_large' in vals:
            self._create_large_attachment()

        return record

    def write(self, vals):
        res = super(Type, self).write(vals)
        if 'type_image_small' in vals:
            self._create_attachment()

        if 'type_image_large' in vals:
            self._create_large_attachment()

        return res

    def serialize(self):
        return {
            'type_name': self.type_name,
            'type_image_small': self.type_image_small,
            'type_image_large': self.type_image_large,
        }
