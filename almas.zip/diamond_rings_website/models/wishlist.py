from odoo import fields, models

class Wishlist(models.Model):
    _name = "diamonds_rings_website.wishlist"

    customer = fields.Many2one('res.users', string="Customer")
    diamond_id = fields.Many2one('diamonds_rings_website.diamond', string="Diamond")
    added_date = fields.Date(string="Added Date")

    
