from odoo import fields, models, api
from odoo.exceptions import ValidationError


class Cart(models.Model):
    _name = "cart"

    customer = fields.Many2one('res.users', string="Customer")
    jewellery_ids = fields.One2many('cart.jewellery', 'cart_id', string="Product Jewellery",store="True")
    diamond_ids = fields.Many2many('diamonds_rings_website.diamond', string="Product Diamond",store="True")
    subtotal = fields.Float(string="Subtotal",store=True,readonly=True)
    amount = fields.Float(string="Total Amount", store=True,readonly=True)


    def update(self):
        for j in self.jewellery_ids:
            price_value = j.jewellery_id.added_values.filtered(lambda v : v.value_name == f"{j.shape} - {j.total_carat}")
            if not price_value:
                raise ValidationError("Pricing value not found")
            j.price = price_value.new_price if price_value.new_price else price_value.price

        jewellery_total = sum(self.jewellery_ids.mapped('price'))

        diamonds_in_offer_ids = self.env['special.offer'].sudo().search(
            [('diamond_id', 'in', self.diamond_ids.mapped('id'))])
        diamonds_not_in_offer_ids = self.diamond_ids.filtered(
            lambda o: o.id not in self.env['special.offer'].sudo().search([]).mapped('diamond_id').ids)
        diamond_total = sum(diamonds_in_offer_ids.mapped('new_price')) + sum(
            diamonds_not_in_offer_ids.mapped('total_sales_price'))
        subtotal = jewellery_total + diamond_total
        amount = subtotal + (subtotal * 5 / 100)
        self.write({'subtotal': subtotal, 'amount': amount})


class CartJewellery(models.Model):
    _name = "cart.jewellery"

    jewellery_id = fields.Many2one('diamonds_rings_website.jewellery')
    cart_id = fields.Many2one('cart')
    ring_size = fields.Char()
    total_carat = fields.Float()
    metal = fields.Many2one('metal')
    shape = fields.Char('shape')
    price = fields.Float("Price")


