from odoo import models, fields

class AddToSpecialOffer(models.TransientModel):

    _name = 'add.special.offer'
    _rec_name = "new_price"
    _description = ''

    new_price = fields.Float(string="New Price")

    def confirm(self):
        print("'''''''''''''''''")
        self.ensure_one()
        print('here')
        diamond_id = self._context.get('default_diamond_id')
        print('***********************')
        print(diamond_id)
        if diamond_id:
            diamond = self.env['diamonds_rings_website.diamond'].browse(diamond_id)
            if diamond:
                special_offer_old_record = self.env['special.offer'].search([('diamond_id', '=', diamond.id)])
                # Update record If already exist in special offer
                if special_offer_old_record:
                    special_offer_old_record.write({
                        'new_price': self.new_price
                    })

                else:
                    # Create a special offer record
                    self.env['special.offer'].create({
                        'diamond_id': diamond.id,
                        'new_price': self.new_price,
                    })
        return {'type': 'ir.actions.act_window_close'}
