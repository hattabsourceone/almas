from odoo import http
from odoo.http import Response
import json
from odoo.http import request

class SpecialOfferController(http.Controller):

    @http.route('/api/v1/get_all_special_offer', auth='none', type='http', method=['GET'], cors='*')
    def get_all_special_offer(self, **kw):
        try:
            special_offers = request.env['special.offer'].sudo().search([])
            headers = {'Content-Type': 'application/json'}
            if special_offers:
                serialized_special_offers = []
                for special_offer in special_offers:
                    # Serialize each special offer
                    serialized_special_offer = {
                        'id': special_offer.id,
                        'image_file': special_offer.image_file if special_offer.image_file else "",
                        'new_price': special_offer.new_price if special_offer.new_price else "",
                        'shape': special_offer.shape.serialize() if special_offer.shape else "",
                        'size_carat': special_offer.size_carat if special_offer.size_carat else "",
                        'color': special_offer.color.serialize() if special_offer.color else "",
                        'cut': special_offer.cut.serialize() if special_offer.cut else "",
                        'clarity': special_offer.clarity.serialize() if special_offer.clarity else "",
                        'symmetry': special_offer.symmetry.serialize() if special_offer.symmetry else "",
                        'polish': special_offer.polish.serialize() if special_offer.polish else "",
                        'fluorescence': special_offer.fluorescence.serialize() if special_offer.fluorescence else "",
                        'certificate': special_offer.certificate if special_offer.certificate else "",
                        'old_price': special_offer.price if special_offer.price else "",
                        'meas_length': special_offer.meas_length if special_offer.meas_length else "",
                        'meas_width': special_offer.meas_width if special_offer.meas_width else "",
                        'meas_depth': special_offer.meas_depth if special_offer.meas_depth else "",
                        'table': special_offer.table_percent if special_offer.table_percent else "",
                        'depth': special_offer.depth_percent if special_offer.depth_percent else "",
                    }
                    serialized_special_offers.append(serialized_special_offer)

                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'special_offers': serialized_special_offers
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code':404,'error': 'No special offers found'}),status=404 ,content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500,'error': str(e)}),status=500 ,headers={'Content-Type': 'application/json'})
