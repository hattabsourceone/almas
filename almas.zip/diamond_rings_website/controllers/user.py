from dataclasses import fields
from itertools import product

from odoo import http
from odoo.http import Response, request
import json
import odoo
from datetime import datetime
import secrets
import string
import stripe
import logging

_logger = logging.getLogger(__name__)

stripe.api_key = "sk_test_51OmCrVA6ShxlZmuh1X6871KMP3sR5orRf0kGlbN1hXo7okkckV4Iexyga67aRlPEcxuxaKJ7FQhz5XA9rEuuYI3A00XwWyWSGQ"
endpoint_secret = 'whsec_2MbLYA628sLRzurcvdbh3LvtrG3IpPYx'

class UserController(http.Controller):

    def _validate_session(self, data):
        session_id = data.get('session_id')
        uid = data.get('uid')
        if not session_id:
            return Response(json.dumps({'code': 400, 'error': 'Session ID is required.'}), status=400, content_type='application/json')

        session_in_come = request.session
        session_in_come.sid = session_id
        session_in_come.db = 'odoo17'
        session_in_come.uid = uid

        session = odoo.http.root.session_store.get(session_in_come.sid)

        if not session:
            return Response(json.dumps({'code': 401, 'error': 'Unauthorized.'}), status=401, content_type='application/json')

        if session.session_expiration and session.session_expiration < datetime.now():
            return Response(json.dumps({'code': 401, 'error': 'Session expired.'}), status=401, content_type='application/json')

        return session

    @http.route('/api/v1/toggle_newsletter', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def toggle_newsletter(self, **kw):
            try:
                request_body = request.httprequest.data.decode('utf-8')
                data = json.loads(request_body)
                session = self._validate_session(data)
                if isinstance(session, Response):
                    return session
                uid = request.session.uid
                if not uid:
                    return Response(json.dumps({'code': 400, 'error': 'User ID is required.'}), status=400, content_type='application/json')
                user = http.request.env['res.users'].sudo().search([('id', '=', uid)], limit=1)
                if not user:
                    return Response(json.dumps({'code': 404, 'error': 'User not found.'}), status=404, content_type='application/json')

                state = data.get('state')
                if state is None:
                    return Response(json.dumps({'code': 400, 'error': 'State field is required.'}), status=400, content_type='application/json')
                user.newsletter = state

                response_body = {
                    'code': 200,
                    'message': 'Newsletter subscription status updated successfully.',
                    'newsletter': user.newsletter
                }
                return Response(json.dumps(response_body), status=200, content_type='application/json')
            except Exception as e:
                return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/update_billing_address', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def update_billing_address(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid

            if not uid:
                return Response(json.dumps({'code': 400, 'error': 'User ID is required.'}), status=400, content_type='application/json')

            user = http.request.env['res.users'].sudo().search([('id', '=', uid)], limit=1)

            if not user:
                return Response(json.dumps({'code': 404, 'error': 'User not found.'}), status=404, content_type='application/json')

            address_id = data.get('id')
            billing_full_name = data.get('billing_full_name')
            billing_mobile_w_country = data.get('billing_mobile_w_country')
            billing_address = data.get('billing_address')
            billing_address_2 = data.get('billing_address_2', '')
            company = data.get('company', '')
            billing_city = data.get('billing_city')
            billing_post_code = data.get('billing_post_code')
            billing_country = data.get('billing_country')
            billing_state = data.get('billing_state')
            is_default = data.get('is_default')

            if not (billing_full_name and billing_mobile_w_country and billing_address and billing_city and billing_post_code and billing_country and billing_state and address_id) :
                return Response(json.dumps({'code':400,'error': 'Missing or empty required fields.'}),status=400, content_type='application/json')

            address = request.env['res.billing'].sudo().search([('id', '=', address_id)])

            if not address:
                return Response(json.dumps({'code':400,'error': 'Address id is wrong.'}), status=400, content_type='application/json')

            values = {
                'full_name': billing_full_name,
                'mobile_w_country': billing_mobile_w_country,
                'address': billing_address,
                'address_2': billing_address_2,
                'company': company,
                'city': billing_city,
                'post_code': billing_post_code,
                'country': billing_country,
                'state': billing_state,
            }

            if is_default:
                user.billing_ids.sudo().write({
                    'is_default': False
                })
                values['is_default'] = is_default

            address.sudo().write(values)

            response_body = {
                'code': 200,
                'message': 'Billing address updated successfully.'
            }

            return Response(json.dumps(response_body), status=200, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/add_billing_address', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def add_billing_address(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid

            if not uid:
                return Response(json.dumps({'code': 400, 'error': 'User ID is required.'}), status=400,
                                content_type='application/json')

            user = http.request.env['res.users'].sudo().search([('id', '=', uid)], limit=1)

            if not user:
                return Response(json.dumps({'code': 404, 'error': 'User not found.'}), status=404,
                                content_type='application/json')

            billing_full_name = data.get('billing_full_name')
            billing_mobile_w_country = data.get('billing_mobile_w_country')
            billing_address = data.get('billing_address')
            billing_address_2 = data.get('billing_address_2', '')
            company = data.get('company', '')
            billing_city = data.get('billing_city')
            billing_post_code = data.get('billing_post_code')
            billing_country = data.get('billing_country')
            billing_state = data.get('billing_state')
            is_default = data.get('is_default')

            if not (
                    billing_full_name and billing_mobile_w_country and billing_address and billing_city and billing_post_code and billing_country and billing_state):
                return Response(json.dumps({'code': 400, 'error': 'Missing or empty required fields.'}), status=400,
                                content_type='application/json')
            if is_default:
                user.billing_ids.sudo().write({
                    'is_default': False
                })

            values = {
                'full_name': billing_full_name,
                'mobile_w_country': billing_mobile_w_country,
                'address': billing_address,
                'address_2': billing_address_2,
                'company': company,
                'city': billing_city,
                'post_code': billing_post_code,
                'country': billing_country,
                'state': billing_state,
                'is_default': is_default,
                'user_id': user.id
            }
            record = request.env['res.billing'].sudo().create(values)
            response_body = {
                'code': 200,
                "id": record.id,
                'message': 'Billing address added successfully.'
            }

            return Response(json.dumps(response_body), status=200, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/delete_billing_address', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def delete_billing_address(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid

            if not uid:
                return Response(json.dumps({'code': 400, 'error': 'User ID is required.'}), status=400,
                                content_type='application/json')

            user = http.request.env['res.users'].sudo().search([('id', '=', uid)], limit=1)

            if not user:
                return Response(json.dumps({'code': 404, 'error': 'User not found.'}), status=404,
                                content_type='application/json')

            address_id = data.get('id')

            if not address_id:
                return Response(json.dumps({'code': 400, 'error': 'Address id is required.'}), status=400,
                                content_type='application/json')

            address = request.env['res.billing'].sudo().search([('id', '=', address_id)])

            if not address:
                return Response(json.dumps({'code': 400, 'error': 'Address id is wrong.'}), status=400,
                                content_type='application/json')

            address.sudo().unlink()

            response_body = {
                'code': 200,
                'message': 'Billing address deleted successfully.'
            }

            return Response(json.dumps(response_body), status=200, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/get_billing_address', auth='none', type='http', methods=['POST', 'GET'], csrf=False, cors='*')
    def get_billing_address(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid

            address_id = data.get('id')

            if not uid:
                return Response(json.dumps({'code': 400, 'error': 'User ID is required.'}), status=400,
                                content_type='application/json')

            user = http.request.env['res.users'].sudo().search([('id', '=', uid)], limit=1)
            if not user:
                return Response(json.dumps({'code': 404, 'error': 'User not found.'}), status=404,
                                content_type='application/json')

            fields = ['id', 'full_name', 'mobile_w_country', 'address','address_2','company', 'city', 'post_code', 'country', 'state', 'is_default']
            response_body = {
                'code': 200,
                'billing_address': user.billing_ids.filtered(lambda ad: ad.id == address_id).read(
                    fields=fields) if address_id else user.billing_ids.read(fields=fields)
            }

            return Response(json.dumps(response_body), status=200, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/update_shipping_address', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def update_shipping_address(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid
            if not uid:
                return Response(json.dumps({'code': 400, 'error': 'User ID is required.'}), status=400, content_type='application/json')

            user = http.request.env['res.users'].sudo().search([('id', '=', uid)], limit=1)

            if not user:
                return Response(json.dumps({'code': 404, 'error': 'User not found.'}), status=404, content_type='application/json')

            address_id = data.get('id')
            shipping_full_name = data.get('shipping_full_name')
            shipping_mobile_w_country = data.get('shipping_mobile_w_country')
            shipping_address = data.get('shipping_address')
            shipping_address_2 = data.get('shipping_address_2', '')
            company = data.get('company', '')
            shipping_city = data.get('shipping_city')
            shipping_post_code = data.get('shipping_post_code')
            shipping_country = data.get('shipping_country')
            shipping_state = data.get('shipping_state')
            is_default = data.get('is_default')

            if not (shipping_full_name and shipping_mobile_w_country and shipping_address and shipping_city and shipping_post_code and shipping_country and shipping_state and address_id) :
                return Response(json.dumps({'code':400,'error': 'Missing or empty required fields.'}),status=400, content_type='application/json')

            address = request.env['res.shipping'].sudo().search([('id', '=', address_id)])

            if not address:
                return Response(json.dumps({'code': 400, 'error': 'Address id is wrong.'}), status=400,
                                content_type='application/json')

            values = {
                "full_name": shipping_full_name,
                "mobile_w_country": shipping_mobile_w_country,
                "address": shipping_address,
                'address_2': shipping_address_2,
                'company': company,
                "city": shipping_city,
                "post_code": shipping_post_code,
                "country": shipping_country,
                "state": shipping_state,
            }

            if is_default:
                user.shipping_ids.sudo().write({
                    'is_default': False
                })
                values['is_default'] = is_default

            address.sudo().write(values)

            response_body = {
                'code': 200,
                'message': 'Shipping address updated successfully.'
            }

            return Response(json.dumps(response_body), status=200, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/add_shipping_address', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def add_shipping_address(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid

            if not uid:
                return Response(json.dumps({'code': 400, 'error': 'User ID is required.'}), status=400,
                                content_type='application/json')

            user = http.request.env['res.users'].sudo().search([('id', '=', uid)], limit=1)

            if not user:
                return Response(json.dumps({'code': 404, 'error': 'User not found.'}), status=404,
                                content_type='application/json')

            shipping_full_name = data.get('shipping_full_name')
            shipping_mobile_w_country = data.get('shipping_mobile_w_country')
            shipping_address = data.get('shipping_address')
            shipping_address_2 = data.get('shipping_address_2', '')
            company = data.get('company', '')
            shipping_city = data.get('shipping_city')
            shipping_post_code = data.get('shipping_post_code')
            shipping_country = data.get('shipping_country')
            shipping_state = data.get('shipping_state')
            is_default = data.get('is_default')

            if not (
                    shipping_full_name and shipping_mobile_w_country and shipping_address and shipping_city and shipping_post_code and shipping_country and shipping_state):
                return Response(json.dumps({'code': 400, 'error': 'Missing or empty required fields.'}), status=400,
                                content_type='application/json')
            if is_default:
                user.shipping_ids.sudo().write({
                    'is_default': False
                })

            values = {
                'full_name': shipping_full_name,
                'mobile_w_country': shipping_mobile_w_country,
                'address': shipping_address,
                'address_2': shipping_address_2,
                'company': company,
                'city': shipping_city,
                'post_code': shipping_post_code,
                'country': shipping_country,
                'state': shipping_state,
                'is_default': is_default,
                "user_id": user.id
            }
            record = request.env['res.shipping'].sudo().create(values)

            response_body = {
                'code': 200,
                "id": record.id,
                'message': 'shipping address added successfully.'
            }

            return Response(json.dumps(response_body), status=200, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/delete_shipping_address', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def delete_shipping_address(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid

            if not uid:
                return Response(json.dumps({'code': 400, 'error': 'User ID is required.'}), status=400,
                                content_type='application/json')

            user = http.request.env['res.users'].sudo().search([('id', '=', uid)], limit=1)

            if not user:
                return Response(json.dumps({'code': 404, 'error': 'User not found.'}), status=404,
                                content_type='application/json')

            address_id = data.get('id')

            if not address_id:
                return Response(json.dumps({'code': 400, 'error': 'Address id is required.'}), status=400,
                                content_type='application/json')

            address = request.env['res.shipping'].sudo().search([('id', '=', address_id)])

            if not address:
                return Response(json.dumps({'code': 400, 'error': 'Address id is wrong.'}), status=400,
                                content_type='application/json')

            address.sudo().unlink()

            response_body = {
                'code': 200,
                'message': 'Shipping address deleted successfully.'
            }

            return Response(json.dumps(response_body), status=200, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/get_shipping_address', auth='none', type='http', methods=['POST','GET'], csrf=False, cors='*')
    def get_shipping_address(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid

            address_id = data.get('id')

            if not uid:
                return Response(json.dumps({'code': 400, 'error': 'User ID is required.'}), status=400, content_type='application/json')

            user = http.request.env['res.users'].sudo().search([('id', '=', uid)], limit=1)
            if not user:
                return Response(json.dumps({'code': 404, 'error': 'User not found.'}), status=404, content_type='application/json')

            fields = ['id', 'full_name', 'mobile_w_country', 'address','address_2','company', 'city', 'post_code', 'country', 'state', 'is_default']

            response_body = {
                'code': 200,
                'shipping_address': user.shipping_ids.filtered(lambda ad: ad.id == address_id).read(fields=fields) if address_id else user.shipping_ids.read(fields=fields)
            }

            return Response(json.dumps(response_body), status=200, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/change_password', auth='none', type='http', methods=['PUT'], csrf=False, cors='*')
    def change_password(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid

            if not uid:
                return Response(json.dumps({'code': 400, 'error': 'User ID is required.'}), status=400,
                                content_type='application/json')

            user = http.request.env['res.users'].sudo().search([('id', '=', uid)], limit=1)

            if not user:
                return Response(json.dumps({'code': 404, 'error': 'User not found.'}), status=404,
                                content_type='application/json')

            old_password = data.get('old_password')
            if not old_password:
                return Response(json.dumps({'code': 400, 'error': 'Missing or empty old_password field.'}), status=400,
                                content_type='application/json')

            password = data.get('password')

            if not password:
                return Response(json.dumps({'code': 400, 'error': 'Missing or empty password field.'}), status=400,
                                content_type='application/json')

            if len(password) < 8:
                return Response(json.dumps({'code': 400, 'error': 'Password must be 8 digits at least.'}), status=400,
                                content_type='application/json')

            try:

                uid = request.env['res.users'].authenticate(request.session.db, str(user.login), str(old_password), {})
            except Exception as e:

                return Response(json.dumps({'code': 400, 'error': 'Wrong password.'}), status=400,
                                content_type='application/json')

            user.sudo().write({
                'password': password
            })

            response_body = {
                'code': 200,
                'message': 'Password changed successfully.'
            }

            return Response(json.dumps(response_body), status=200, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/reset_password', auth='none', type='http', methods=['PUT'], csrf=False, cors='*')
    def reset_password(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            login = data.get('email')

            if not login:
                return Response(json.dumps({'code': 400, 'error': 'Missing or empty email field.'}), status=400,
                                content_type='application/json')

            user = http.request.env['res.users'].sudo().search([('login', '=', login)], limit=1)

            if not user:
                return Response(json.dumps({'code': 404, 'error': 'User not found.'}), status=404,
                                content_type='application/json')

            alphabet = string.ascii_letters + string.digits
            password = ''.join(secrets.choice(alphabet) for i in range(20))
            user.sudo().write({
                'password': password
            })

            template = request.env.ref('diamond_rings_website.email_reset_password_template')
            template.with_context({'pass': password}).sudo().send_mail(user.id, force_send=True)
            response_body = {
                'code': 200,
                'message': 'Password reset successfully.'
            }

            return Response(json.dumps(response_body), status=200, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/update_user_info', auth='none', type='http', methods=['PUT'], csrf=False, cors='*')
    def update_user_info(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid
            if not uid:
                return Response(json.dumps({'code': 400, 'error': 'User ID is required.'}), status=400,
                                content_type='application/json')

            user = http.request.env['res.users'].sudo().search([('id', '=', uid)], limit=1)

            if not user:
                return Response(json.dumps({'code': 404, 'error': 'User not found.'}), status=404,
                                content_type='application/json')

            name = data.get('name')
            login = data.get('email')
            phone = data.get('phone')

            if not (name and login and phone):
                return Response(json.dumps({'code': 400, 'error': 'Missing or empty required fields.'}), status=400,
                                content_type='application/json')

            values = {
                "name": name,
                "login": login,
                "phone": phone,
            }

            user.sudo().write(values)

            response_body = {
                'code': 200,
                'message': 'Shipping address updated successfully.'
            }

            return Response(json.dumps(response_body), status=200, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/get_checkout_link', auth='none', methods=['POST', 'GET'], csrf=False, cors='*')
    def get_checkout_link(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid
            if not uid:
                return Response(json.dumps({'code': 400, 'error': 'User ID is required.'}), status=400,
                                content_type='application/json')

            user = http.request.env['res.users'].sudo().search([('id', '=', uid)], limit=1)
            if not user:
                return Response(json.dumps({'code': 404, 'error': 'User not found.'}), status=404,
                                content_type='application/json')

            if user.status != 'verified':
                return Response(json.dumps({'code': 401, 'error': 'User not verified.'}), status=404,
                                content_type='application/json')

            customer_data = data['data']
            user_cart = request.env['cart'].sudo().search([('customer', '=', uid)],order="id desc", limit=1)
            if not user_cart:
                return Response(json.dumps({'code': 404, 'error': 'User has empty cart.'}), status=404,
                                content_type='application/json')
            if not user_cart.diamond_ids and not user_cart.jewellery_ids:
                return Response(json.dumps({'code': 404, 'error': 'User has empty cart.'}), status=404,
                                content_type='application/json')

            user_cart.update()
            customer_data['amount'] = user_cart.amount
            customer_data['subtotal'] = user_cart.subtotal
            customer_data['jewellery_ids'] = json.dumps(user_cart.jewellery_ids.ids)
            customer_data['diamond_ids'] = json.dumps(user_cart.diamond_ids.ids)
            price_items = []
            for j in user_cart.jewellery_ids:
                product_id = stripe.Product.create(name=j.jewellery_id.name)
                price = stripe.Price.create(
                    product=product_id,
                    unit_amount= int(j.price) * 100,
                    currency="usd",
                )
                price_items.append({'price': price, "quantity": 1})

            for d in user_cart.diamond_ids:
                diamond_in_special = request.env['special.offer'].sudo().search([('diamond_id', '=', d.id)])
                diamond_price = diamond_in_special.new_price if diamond_in_special else d.total_sales_price
                product_name = f"{d.diamond_size} - Carat {d.shape.serialize()['value_name']}" if d.shape.serialize()['value_name'] else f"{d.diamond_size} - Carat diamond"
                product_id = stripe.Product.create(name=product_name)
                price = stripe.Price.create(
                    product=product_id,
                    unit_amount=int(diamond_price) * 100,
                    currency="usd",
                )
                price_items.append({'price': price, "quantity": 1})

            vat_product = stripe.Product.create(name="VAT")
            vat_price = stripe.Price.create(
                product=vat_product,
                unit_amount=int(user_cart.subtotal) * 5 ,
                currency="usd",
            )
            price_items.append({'price': vat_price, "quantity": 1})
            response_body = stripe.PaymentLink.create(
                line_items=price_items,
            )

            customer_data['payment_link_id'] = response_body.id
            response_body = stripe.PaymentLink.modify(
                response_body.id,
                payment_intent_data={'metadata': customer_data}
            )

            # user_cart.unlink()
            return Response(json.dumps(response_body), status=200, content_type='application/json')
        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/webhook', auth='none', type='json', methods=['POST'], csrf=False)
    def webhook(self):
        event = None
        payload = request.httprequest.data
        try:
            event = json.loads(payload)
        except json.decoder.JSONDecodeError as e:
            return {'code': 500, 'success': False}

        if endpoint_secret:
            # Only verify the event if there is an endpoint secret defined
            # Otherwise use the basic event deserialized with json
            sig_header = request.httprequest.headers.get('stripe-signature')
            try:
                event = stripe.Webhook.construct_event(
                    payload, sig_header, endpoint_secret
                )
            except stripe.error.SignatureVerificationError as e:
                return {'code': 500, 'success': False}

        # Handle the event
        if event and event['type'] == 'payment_intent.succeeded':
            payment_intent = event['data']['object']  # contains a stripe.PaymentIntent
            data = payment_intent['metadata']
            payment_link_id = data['payment_link_id']
            order = request.env['order'].sudo().create({
                "customer":data['customer'],
                'purchase_date': datetime.now(),
                "payment_intent":payment_intent['id'],
                "amount":data['amount'],
                "subtotal":data['subtotal'],
                "jewellery_ids": json.loads(data['jewellery_ids']),
                "diamond_ids": json.loads(data['diamond_ids']),
                "billing_address": data['billing_address'],
                "shipping_address": data['shipping_address'],
                "notes": data['notes'],
                "status": "order_placed"
            })
            user_cart = request.env['cart'].sudo().search([('customer', '=', int(data['customer']))])
            user_cart.unlink()
            template = request.env.ref('diamond_rings_website.email_order_placed_template')
            template.sudo().send_mail(order, force_send=True)
            stripe.PaymentLink.modify(
                payment_link_id,
                active=False
            )
            # Then define and call a method to handle the successful payment intent.
            # handle_payment_intent_succeeded(payment_intent)
        elif event['type'] == 'payment_intent.canceled':
            payment_intent = event['data']['object']  # contains a stripe.PaymentMethod
            order = request.env['order'].sudo().search([('payment_intent', '=', payment_intent['id'])])
            order.write({
                "status":"canceled"
            })
            # Then define and call a method to handle the successful attachment of a PaymentMethod.
            # handle_payment_method_attached(payment_method)
        else:
            # Unexpected event type
            print('Unhandled event type {}'.format(event['type']))

        return {'code': 500, 'success': False}
