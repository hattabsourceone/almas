from odoo import http
from odoo.http import Response
import json
from odoo.http import request

class Email(http.Controller):

    @http.route('/api/v1/add_email', auth='none', type='http', method=['POST'], csrf=False, cors='*')
    def add_email(self, **post):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body) 
            email = data.get('email')

            # Check if any required field is missing or empty
            if not email:
                return Response(json.dumps({'code':400,'error': 'Email field is required.'}),status=400 ,content_type='application/json')
            
            # Convert file data to base64
            # file_base64 = base64.b64encode(file_data).decode('utf-8') if file_data else ""
            email_obj = http.request.env['email'].sudo()
            email_record = email_obj.create({
                'name' : email,
            })
            
            # Prepare the response
            headers = {'Content-Type': 'application/json'}
            if email_record:
                body = {
                    'results': {'code': 200, 'message': 'Record Added'},
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code':500,'error': 'Failed to send request.'}),status=500, content_type='application/json')
        
        except Exception as e:
            return Response(json.dumps({'code':500,'error': str(e)}), status=500 ,content_type='application/json')
