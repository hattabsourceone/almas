from odoo import http
from odoo.http import Response
import json
import base64
from odoo.http import request

class CategoryController(http.Controller):

    @http.route('/api/v1/get_all_categories', auth='none', type='http', method=['GET'], cors='*')
    def get_all_categories(self, **kw):
        try:
            categories = request.env['diamonds_rings_website.category'].sudo().search([])

            headers = {'Content-Type': 'application/json'}
            if categories:
                serialized_categories = []
                for category in categories:
                    types = []
                    for category_type in category.category_type_name_lines:
                        # image_small_data = category_type.type_image_small
                        # image_small_base64 = base64.b64encode(image_small_data).decode('utf-8') if image_small_data else ""
                        types.append({
                            'id': category_type.id,
                            'title': category_type.type_name,
                            'image_url': category_type.image_url or "",
                            # 'small_image': image_small_base64,
                        })
                    # category_image = base64.b64encode(category.catgeory_image).decode('utf-8') if category.catgeory_image else ""
                    serialized_categories.append({
                        'id': category.id,
                        'title': category.category_name,
                        'types': types
                    })
                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'categories': serialized_categories
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code':404, 'error': 'No categories found'}),status=404 ,content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code':500,'error': str(e)}),status=500 ,headers={'Content-Type': 'application/json'})

    @http.route('/api/v1/shop_all_jewellery', auth='none', type='http', method=['GET'], cors='*')
    def shop_all_jewellery(self, **kw):
        try:
            categories = request.env['diamonds_rings_website.category'].sudo().search([])

            headers = {'Content-Type': 'application/json'}
            if categories:
                serialized_categories = []
                for category in categories:
                    category_image = category.image_url if category.image_url else ""
                    # category_image = base64.b64encode(category.catgeory_image).decode('utf-8') if category.catgeory_image else ""
                    serialized_categories.append({
                        'id': category.id,
                        'title': category.category_name,
                        'category_image': category_image
                    })
                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'categories': serialized_categories
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code' : 404,'error': 'No categories found'}),status=404 ,content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code':500,'error': str(e)}), status=500,headers={'Content-Type': 'application/json'})

    @http.route('/api/v1/get_all_metal', auth='none', type='http', method=['GET', 'POST'], csrf=False, cors='*')
    def get_all_metal(self, **kw):
        try:
            metals = request.env['metal'].sudo().search([])

            headers = {'Content-Type': 'application/json'}
            if metals:
                serialized_metal = []
                for metal in metals:
                    serialized_metal.append({
                        "id": metal.id,
                        "name": metal.metal_name
                    })
                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'metals': serialized_metal
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code':404, 'error': 'No categories found'}),status=404 ,content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code':500,'error': str(e)}),status=500 ,headers={'Content-Type': 'application/json'})

    @http.route('/api/v1/get_type_by_category', auth='none', type='http', method=['GET', 'POST'], csrf=False, cors='*')
    def get_types_by_category(self, **kw):
        try:
            request_body = http.request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            category_id = data.get('category_id')
            if not category_id:
                return Response(json.dumps({'code':404, 'error': 'category_id is required field.'}),status=404 ,content_type='application/json')

            types = request.env['diamonds_rings_website.type'].sudo().search([('type_id', '=', category_id)])
            print(types)

            headers = {'Content-Type': 'application/json'}
            if types:
                serialized_types = []
                for type in types:
                    serialized_types.append({
                        "id": type.id,
                        "name": type.type_name,
                    })
                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'types': serialized_types
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code':404, 'error': 'No categories found'}),status=404 ,content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code':500,'error': str(e)}),status=500 ,headers={'Content-Type': 'application/json'})
