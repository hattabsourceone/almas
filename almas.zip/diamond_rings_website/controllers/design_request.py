from odoo import http
from odoo.http import Response
import json
import base64
from odoo.http import request

class DesignRequest(http.Controller):

    @http.route('/api/v1/send_design_request', auth='none', type='http', method=['POST'], csrf=False, cors='*')
    def send_design_request(self, **post):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body) 
            full_name = data.get('full_name')
            email_address = data.get('email_address')
            address = data.get('address')
            mobile_number = data.get('mobile_number')
            type = data.get('type')
            metal = data.get('metal')
            country = data.get('country')
            file_data = data.get('file')
            message = data.get('message')
            
            # Check if any required field is missing or empty
            required_fields = ['full_name', 'email_address', 'address', 'mobile_number', 'type', 'metal', 'country', 'message']
            if not all(data.get(field) for field in required_fields):
                return Response(json.dumps({'code':400,'error': 'Missing or empty required fields.'}),status=400 ,content_type='application/json')
            
            # Convert file data to base64
            # file_base64 = base64.b64encode(file_data).decode('utf-8') if file_data else ""
            file_base64 = file_data
            DesignRequest = http.request.env['diamonds_rings_website.design.request'].sudo()
            design_request_record = DesignRequest.create({
                'full_name' : full_name,
                'email_address' : email_address,
                'address' : address,
                'mobile_number' : mobile_number,
                'type' : type,
                'metal' : metal,
                'country' : country,
                'file' : file_base64,
                'message' : message,
            })
            
            # Prepare the response
            headers = {'Content-Type': 'application/json'}
            if design_request_record:
                body = {
                    'results': {'code': 200, 'message': 'Design request sent successfully'},
                    'id': design_request_record.id,
                    'full_name' : full_name,
                    'email_address' : email_address,
                    'address' : address,
                    'mobile_number' : mobile_number,
                    'type' : type,
                    'metal' : metal,
                    'country' : country,
                    'file' : file_base64,
                    'message' : message,
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code':500,'error': 'Failed to send design request.'}),status=500, content_type='application/json')
        
        except Exception as e:
            return Response(json.dumps({'code':500,'error': str(e)}), status=500 ,content_type='application/json')
