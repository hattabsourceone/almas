from odoo import http
from odoo.http import request
from odoo.http import Response
import json
from datetime import datetime
import odoo

class ProductController(http.Controller):

    def _validate_session(self, data):
        session_id = data.get('session_id')
        uid = data.get('uid')
        if not session_id:
            return Response(json.dumps({'code': 400, 'error': 'Session ID is required.'}), status=400, content_type='application/json')

        session_in_come = request.session
        session_in_come.sid = session_id
        session_in_come.db = 'odoo17'
        session_in_come.uid = uid

        session = odoo.http.root.session_store.get(session_in_come.sid)

        if not session:
            return Response(json.dumps({'code': 401, 'error': 'Unauthorized.'}), status=401, content_type='application/json')

        if session.session_expiration and session.session_expiration < datetime.now():
            return Response(json.dumps({'code': 401, 'error': 'Session expired.'}), status=401, content_type='application/json')

        return session

    @http.route('/api/v1/check_product_status', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def check_product_status(self, **post):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid
            diamond_id = data.get('diamond_id')

            if not diamond_id:
                return Response(json.dumps({'code': 400, 'error': 'Missing diamond_id field.'}), status=400, content_type='application/json')

            # Check in Wishlist
            Wishlist = request.env['diamonds_rings_website.wishlist'].sudo()
            wishlist_record = Wishlist.search([('customer', '=', uid), ('diamond_id', '=', diamond_id)])
            in_wishlist = bool(wishlist_record)

            # Check in Compared Diamonds
            CompareDiamond = request.env['diamonds_rings_website.compare.diamond'].sudo()
            compare_diamond_record = CompareDiamond.search([('customer', '=', uid), ('diamond_id', '=', diamond_id)])
            in_compare_diamonds = bool(compare_diamond_record)
            
            # Check in Cart
            Cart = request.env['cart'].sudo()
            cart_records = Cart.search([('customer', '=', uid), ('diamond_ids', '=', diamond_id)])
            in_cart = bool(cart_records)

            headers = {'Content-Type': 'application/json'}
            body = {
                'results': {'code': 200, 'message': 'OK'},
                'data': {
                    'in_wishlist': in_wishlist,
                    'in_compare_diamonds': in_compare_diamonds,
                    'in_cart': in_cart
                }
            }
            return Response(json.dumps(body), headers=headers)

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

