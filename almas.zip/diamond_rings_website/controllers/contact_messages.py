from odoo import http
from odoo.http import Response
import json
from odoo.http import request

class MessagesController(http.Controller):

    @http.route('/api/v1/send_contact_messages', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def send_contact_messages(self, **post):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            full_name = data.get('full_name')
            email_address = data.get('email_address')
            mobile_number = data.get('mobile_number')
            country = data.get('country')
            message = data.get('message')
            
            # Check if any required field is missing or empty
            required_fields = ['full_name', 'email_address', 'mobile_number', 'country', 'message']
            if not all(data.get(field) for field in required_fields):
                return Response(json.dumps({'code':400,'error': 'Missing or empty required fields.'}),status=400, content_type='application/json')
            
            # Create a record in the corresponding model
            Message = request.env['diamonds_rings_website.contact'].sudo()
            message_record = Message.create({
                'full_name': full_name,
                'email_address': email_address,
                'mobile_number': mobile_number,
                'country': country,
                'message': message,
            })

            # Prepare the response
            headers = {'Content-Type': 'application/json'}
            if message_record:
                body = {
                    'results': {'code': 200, 'message': 'Message sent successfully'},
                    'id': message_record.id,
                    'full_name': full_name,
                    'email_address': email_address,
                    'mobile_number': mobile_number,
                    'country': country,
                    'message': message,
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code':500,'error': 'Failed to send message.'}),status=500 ,content_type='application/json')
        
        except Exception as e:
            return Response(json.dumps({'code':500,'error': str(e)}),status=500 ,content_type='application/json')
