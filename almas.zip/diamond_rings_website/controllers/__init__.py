from . import get_diamonds,contact_messages,design_request,get_types,get_jewellery,get_categories, order
from . import get_questions,log_in, sign_up, wishlist, compare_diamond, get_special_offer, get_payment_providers
from . import user, cart, product, email