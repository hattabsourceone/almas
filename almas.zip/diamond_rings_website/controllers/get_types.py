from odoo import http
from odoo.http import Response
from odoo.exceptions import ValidationError
import json
import base64
class TypeController(http.Controller):

    @http.route('/api/v1/get_types_by_category', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def get_types_by_category(self, **kw):
        try:
            request_data = json.loads(http.request.httprequest.data.decode('utf-8'))
            category_name = request_data.get('category_name')
            
            if not category_name:
                return Response(json.dumps({'code':400 ,'error': 'Category name is required.'}), status=400, content_type='application/json')
            
            category = http.request.env['diamonds_rings_website.category'].sudo().search([('category_name', '=', category_name)])
            
            if not category:
                return Response(json.dumps({'code':404 ,'error': 'Category not found.'}), status=404, content_type='application/json')

            types = []
            for category_type in category.category_type_name_lines:
                # type_image_large_base64 = base64.b64encode(category_type.type_image_large).decode('utf-8') if category_type.type_image_large else ""
                types.append({
                    'id': category_type.id,
                    'type_name': category_type.type_name,
                    'type_image_large': category_type.large_image_url or "",
                })
            
            response_body = {
                'results': {'code': 200, 'message': 'OK'},
                'category_id': category.id,
                'category_name': category.category_name,
                'category_desc': category.category_desc,
                'types': types
            }
            
            return Response(json.dumps(response_body), status=200, content_type='application/json')
        
        except ValidationError as e:
            return Response(json.dumps({'code': 400,'error': e.name}), status=400, content_type='application/json')
        
        except Exception as e:
            return Response(json.dumps({'code': 500,'error': str(e)}), status=500, content_type='application/json')
