from odoo import http
from odoo.http import request, Response
import json
from datetime import datetime
import odoo
import base64
class CartController(http.Controller):

    def _validate_session(self, data):
        session_id = data.get('session_id')
        uid = data.get('uid')
        if not session_id:
            return Response(json.dumps({'code': 400, 'error': 'Session ID is required.'}), status=400, content_type='application/json')

        session_in_come = request.session
        session_in_come.sid = session_id
        session_in_come.db = 'odoo17'
        session_in_come.uid = uid

        session = odoo.http.root.session_store.get(session_in_come.sid)

        if not session:
            return Response(json.dumps({'code': 401, 'error': 'Unauthorized.'}), status=401, content_type='application/json')

        if session.session_expiration and session.session_expiration < datetime.now():
            return Response(json.dumps({'code': 401, 'error': 'Session expired.'}), status=401, content_type='application/json')

        return session

    def _get_user_cart(self, user_id):
        cart = request.env['cart'].sudo().search([('customer', '=', user_id)],order="id desc", limit=1)
        if not cart:
            cart = request.env['cart'].sudo().create({'customer': user_id})
        return cart

    def   _update_cart_totals(self, cart):
        cart.update()

    @http.route('/api/v1/add_to_cart', auth='none', type='http', method=['POST'], cors='*', csrf=False)
    def add_to_cart(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid
            product_type = data.get('product_type')
            product_id = data.get('product_id')
            ring_size = data.get('ring_size')
            total_carat = data.get('total_carat')
            metal = data.get('metal_id')
            shape = data.get('shape')
            if not product_type or not product_id:
                return Response(json.dumps({'code': 400, 'error': 'product_type and product_id are required'}), status=400, content_type='application/json')

            cart = self._get_user_cart(uid)
            if product_type == 'jewellery':
                if not total_carat or not shape:
                    return Response(json.dumps({'code': 400, 'error': 'total_carat and shape are required'}),
                                    status=400, content_type='application/json')

                product = request.env['diamonds_rings_website.jewellery'].sudo().browse(product_id)
                if not product.exists():
                    return Response(json.dumps({'code': 404, 'error': 'Jewellery not found'}), status=404, content_type='application/json')

                if product.id in cart.jewellery_ids.mapped('jewellery_id').ids:
                # omar alsawaf 13/10/2024 after adding cart_jewellery model
                # if product.id in cart.jewellery_ids.ids:
                    return Response(json.dumps({'code': 409, 'error': 'Jewellery already in cart'}), status=409, content_type='application/json')

                cart.jewellery_ids = [(0, 0, {'jewellery_id':product.id, 'ring_size': ring_size, "total_carat": total_carat, "metal": metal, 'shape':shape})]
                # omar alsawaf 13/10/2024 after adding cart_jewellery model
                # cart.jewellery_ids = [(4, product.id)]
            elif product_type == 'diamond':
                product = request.env['diamonds_rings_website.diamond'].sudo().search([('id', '=', product_id)])
                if not product.exists():
                    return Response(json.dumps({'code': 404, 'error': 'Diamond not found'}), status=404, content_type='application/json')
                if product.id in cart.diamond_ids.ids:
                    return Response(json.dumps({'code': 409, 'error': 'Diamond already in cart'}), status=409, content_type='application/json')
                cart.diamond_ids = [(4, product.id)]
            else:
                return Response(json.dumps({'code': 400, 'error': 'Invalid product_type'}), status=400, content_type='application/json')

            self._update_cart_totals(cart)
            response_body = {
                'results': {'code': 200, 'message': 'OK'},
                'cart_id': cart.id,
            }
            return Response(json.dumps(response_body), status=200, content_type='application/json')
        except Exception as e:
            print(e)
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/remove_from_cart', auth='none', type='http', method=['POST'], cors='*', csrf=False)
    def remove_from_cart(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid
            product_type = data.get('product_type')
            product_id = data.get('product_id')

            if not product_type or not product_id:
                return Response(json.dumps({'code': 400, 'error': 'product_type and product_id are required'}), status=400, content_type='application/json')

            cart = self._get_user_cart(uid)
            if not cart:
                return Response(json.dumps({'code': 404, 'error': 'Cart not found'}), status=404, content_type='application/json')

            if product_type == 'jewellery':
                product = request.env['diamonds_rings_website.jewellery'].sudo().browse(product_id)
                if product.exists():
                    line_id = cart.jewellery_ids.filtered(lambda j: j.jewellery_id.id == product.id)
                    cart.jewellery_ids = [(3, line_id.id)]
                    # omar alsawaf 13/10/2024 after adding cart_jewellery model
                    # cart.jewellery_ids = [(3, product.id)]
                else:
                    return Response(json.dumps({'code': 404, 'error': 'Jewellery not found'}), status=404, content_type='application/json')
            elif product_type == 'diamond':
                product = request.env['diamonds_rings_website.diamond'].sudo().browse(product_id)
                if product.exists():
                    cart.diamond_ids = [(3, product.id)]
                else:
                    return Response(json.dumps({'code': 404, 'error': 'Diamond not found'}), status=404, content_type='application/json')
            else:
                return Response(json.dumps({'code': 400, 'error': 'Invalid product_type'}), status=400, content_type='application/json')

            self._update_cart_totals(cart)
            response_body = {
                'results': {'code': 200, 'message': 'OK'},
                'cart_id': cart.id,
            }
            return Response(json.dumps(response_body), status=200, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/get_cart', auth='none', type='http', method=['POST'], cors='*', csrf=False)
    def get_cart(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid
            cart = self._get_user_cart(uid)
            if not cart:
                return Response(json.dumps({'code': 404, 'error': 'Cart not found'}), status=404, content_type='application/json')

            self._update_cart_totals(cart)
            jewellery_data_list = []
            for jewellery in cart.jewellery_ids:
                # omar alsawaf 13/10/2024 after adding cart_jewellery model
                # jewellery_data = {
                #     'id': jewellery.id,
                #     'name': jewellery.name,
                #     'category': jewellery.category.category_name if jewellery.category else '',
                #     'type': jewellery.type.type_name if jewellery.type else '',
                #     'sku': jewellery.sku,
                #     'desc': jewellery.desc,
                #     'price': jewellery.price,
                #     'image_lines': []
                # }
                # omar alsawaf 13/10/2024 after adding cart_jewellery model
                # get jewellery data from jewellery.jewellery_id rather than jewellery
                jewellery_data = {
                    'id': jewellery.jewellery_id.id,
                    'name': jewellery.jewellery_id.name,
                    'category': jewellery.jewellery_id.category.category_name if jewellery.jewellery_id.category else '',
                    'type': jewellery.jewellery_id.type.type_name if jewellery.jewellery_id.type else '',
                    'sku': jewellery.jewellery_id.sku,
                    'desc': jewellery.jewellery_id.desc,
                    'price': jewellery.price,
                    'ring_size': jewellery.ring_size if jewellery.ring_size else 0,
                    'total_carat': jewellery.total_carat if jewellery.total_carat else "",
                    'shape': jewellery.shape if jewellery.shape else "",
                    'metal': {'name': jewellery.metal.metal_name, 'id': jewellery.metal.id} if jewellery.metal else {},
                    'image_lines': []
                }
                if jewellery.jewellery_id.image_lines:
                    first_image = jewellery.jewellery_id.image_lines[0]
                    # video_file_base64 = base64.b64encode(first_image.video_file).decode('utf-8') if first_image.video_file else ""
                    image_data = {
                        'id': first_image.id,
                        'image_type_name': first_image.image_type_name,
                        # 'video_file': video_file_base64,
                        'images_urls': [],
                        'shape_value': first_image.shape_value,
                        'metal_value': first_image.metal_value,
                    }
                    if first_image.image_file:
                        attachment = first_image.image_file[0]
                        if attachment.datas:
                            # image_base64 = base64.b64encode(attachment.datas).decode('utf-8')
                            image_data['images_urls'].append(attachment.url)
                    jewellery_data['image_lines'].append(image_data)
                jewellery_data_list.append(jewellery_data)

            diamond_data_list = []
            for diamond in cart.diamond_ids:
                special_offer = request.env['special.offer'].sudo().search([('diamond_id', '=', diamond.id)])
                diamond_price = special_offer.new_price if special_offer else diamond.total_sales_price
                diamond_data = {
                    'id': diamond.id,
                    'diamond_id': diamond.diamond_id,
                    'shape': diamond.shape.serialize() if diamond.shape else "", 
                    'diamond_size': diamond.diamond_size,
                    'color': diamond.color.serialize() if diamond.color else "",
                    'clarity': diamond.clarity.serialize() if diamond.clarity else "",
                    'cut': diamond.cut.serialize() if diamond.cut else "",
                    'symmetry': diamond.symmetry.serialize() if diamond.symmetry else "",
                    'polish': diamond.polish.serialize() if diamond.polish else "",
                    'fluor_intensity': diamond.fluor_intensity.serialize() if diamond.fluor_intensity else "",
                    'image_file': diamond.image_file if diamond.image_file else "",
                    'total_sales_price': diamond_price,
                    'lab': diamond.lab,
                }
                diamond_data_list.append(diamond_data)

            cart_data = {
                'cart_id': cart.id,
                'jewellery': jewellery_data_list,
                'diamond': diamond_data_list,
                'subtotal': cart.subtotal,
                'amount': cart.amount
            }
            # response_body = {
            #     'results': {'code': 200, 'message': 'OK'},
            #     'cart_id': cart.id,
            # }
            return Response(json.dumps({'code': 200, 'cart': cart_data}), status=200, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')
        

    # @http.route('/api/v1/add_product_list_to_cart', auth='none', type='http', method=['POST'], cors='*', csrf=False)
    # def add_product_list_to_cart(self, **kw):
    #     try:
    #         request_body = request.httprequest.data.decode('utf-8')
    #         data = json.loads(request_body)
    #
    #         session = self._validate_session(data)
    #         if isinstance(session, Response):
    #             return session
    #
    #         uid = request.session.uid
    #         jewellery_ids = data.get('jewellery_ids', [])
    #         diamond_ids = data.get('diamond_ids', [])
    #
    #         cart = self._get_user_cart(uid)
    #
    #         for jewellery_id in jewellery_ids:
    #             product = request.env['diamonds_rings_website.jewellery'].sudo().browse(jewellery_id)
    #             if product.exists() and product.id not in cart.jewellery_ids.ids:
    #                 cart.jewellery_ids = [(4, product.id)]
    #
    #         for diamond_id in diamond_ids:
    #             product = request.env['diamonds_rings_website.diamond'].sudo().browse(diamond_id)
    #             if product.exists() and product.id not in cart.diamond_ids.ids:
    #                 cart.diamond_ids = [(4, product.id)]
    #
    #         self._update_cart_totals(cart)
    #
    #         jewellery_data_list = []
    #         for jewellery in cart.jewellery_ids:
    #             jewellery_data = {
    #                 'id': jewellery.id,
    #                 'name': jewellery.name,
    #                 'category': jewellery.category.category_name if jewellery.category else '',
    #                 'type': jewellery.type.type_name if jewellery.type else '',
    #                 'sku': jewellery.sku,
    #                 'desc': jewellery.desc,
    #                 'price': jewellery.price,
    #                 'image_lines': []
    #             }
    #             if jewellery.image_lines:
    #                 first_image = jewellery.image_lines[0]
    #                 video_file_base64 = base64.b64encode(first_image.video_file).decode('utf-8') if first_image.video_file else ""
    #                 image_data = {
    #                     'id': first_image.id,
    #                     'image_type_name': first_image.image_type_name,
    #                     'video_file': video_file_base64,
    #                     'images_base64': [],
    #                     'shape_value': first_image.shape_value,
    #                     'metal_value': first_image.metal_value,
    #                 }
    #                 if first_image.image_file:
    #                     attachment = first_image.image_file[0]
    #                     if attachment.datas:
    #                         image_base64 = base64.b64encode(attachment.datas).decode('utf-8')
    #                         image_data['images_base64'].append(image_base64)
    #                 jewellery_data['image_lines'].append(image_data)
    #             jewellery_data_list.append(jewellery_data)
    #
    #         diamond_data_list = []
    #         for diamond in cart.diamond_ids:
    #             diamond_data = {
    #                 'id': diamond.id,
    #                 'diamond_id': diamond.diamond_id,
    #                 'shape': diamond.shape.serialize() if diamond.shape else "",
    #                 'diamond_size': diamond.diamond_size,
    #                 'color': diamond.color.serialize() if diamond.color else "",
    #                 'clarity': diamond.clarity.serialize() if diamond.clarity else "",
    #                 'cut': diamond.cut.serialize() if diamond.cut else "",
    #                 'symmetry': diamond.symmetry.serialize() if diamond.symmetry else "",
    #                 'polish': diamond.polish.serialize() if diamond.polish else "",
    #                 'fluor_intensity': diamond.fluor_intensity.serialize() if diamond.fluor_intensity else "",
    #                 'image_file': diamond.image_file if diamond.image_file else "",
    #                 'total_sales_price': diamond.total_sales_price
    #             }
    #             diamond_data_list.append(diamond_data)
    #
    #         cart_data = {
    #             'cart_id': cart.id,
    #             'jewellery': jewellery_data_list,
    #             'diamond': diamond_data_list,
    #             'subtotal': cart.subtotal,
    #             'amount': cart.amount
    #         }
    #
    #         return Response(json.dumps({'code': 200, 'cart': cart_data}), status=200, content_type='application/json')
    #
    #     except Exception as e:
    #         return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')
    #