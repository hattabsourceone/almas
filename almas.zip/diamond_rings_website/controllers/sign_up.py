from odoo import http
from odoo.http import request
import json

class UserController(http.Controller):

    @http.route('/api/v1/create_user', type='http', auth='public', methods=['POST'], cors='*', csrf=False)
    def create_user(self, **post):
        request_body = request.httprequest.data.decode('utf-8')
        data = json.loads(request_body) 
        name = data.get('name')
        login = data.get('login')
        email = data.get('email')
        password = data.get('password')
        newsletter = data.get('subscribe')

        # Check if a user with the same login already exists
        existing_user = request.env['res.users'].sudo().search([('login', '=', login)], limit=1)
        if existing_user:
            return request.make_response(json.dumps({'code':400,'error': 'User already exists'}), status=400, headers={'Content-Type': 'application/json'})

        # Fetch the 'Public' group (restricted access group)
        public_group = request.env.ref('base.group_public')

        # Create the user and assign only the 'Public' group
        user = request.env['res.users'].sudo().create({
            'name': name,
            'login': login,
            'email': email,
            'password': password,
            'newsletter': newsletter,
            'is_api_created': True, 
            'groups_id': [(6, 0, [public_group.id])]
        })

        return request.make_response(json.dumps({'code':200,'message': 'User created successfully!', 'data': {"id": user.id}}), headers={'Content-Type': 'application/json'})
