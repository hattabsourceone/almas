from odoo import http
from odoo.http import Response
import json
import base64
from odoo.http import request
import logging

_logger = logging.getLogger(__name__)

class JewelleryController(http.Controller):

    @http.route('/api/v1/get_all_jewelleries_by_category', auth='none', type='http', method=['POST', 'GET'], cors='*', csrf=False)
    def get_all_jewelleries_by_category(self, **kw):
        try:
            request_body = http.request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            category_name = data.get('category_name')

            # Check if category_name is missing or empty
            if not category_name:
                return Response(json.dumps({'code': 400, 'error': 'category_name is required and cannot be empty'}), status=400, content_type='application/json')

            jewellery_records = http.request.env['diamonds_rings_website.jewellery'].sudo(
            ).search([('category', '=', category_name)])

            headers = {'Content-Type': 'application/json'}
            jewellery_data_list = []

            if jewellery_records:
                jewellery_data = []
                for jewellery in jewellery_records:
                    jewellery_data = {
                        'id': jewellery.id,
                        'name': jewellery.name,
                        'category': jewellery.category.category_name if jewellery.category else '',
                        'type': jewellery.type.type_name if jewellery.type else '',
                        'sku': jewellery.sku,
                        'desc': jewellery.desc,
                        'price': jewellery.price,
                        'discount_price': jewellery.discount_price,
                        'image_lines': []
                    }
                    for image in jewellery.image_lines:
                        # video_file_base64 = base64.b64encode(image.video_file).decode(
                        #     'utf-8') if image.video_file else ""
                        image_data = {
                            'id': image.id,
                            'image_type_name': image.image_type_name,
                            'video_file': image.video_file_attachment_id.url if image.video_file_attachment_id else "",
                            'images_urls': [],
                            'shape_value': image.shape_value,
                            'metal_value': image.metal_value,
                        }
                        for attachment in image.image_file:
                            if attachment.url:
                                # image_base64 = base64.b64encode(
                                #     attachment.datas).decode('utf-8')
                                image_data['images_urls'].append(
                                    attachment.url)

                        jewellery_data['image_lines'].append(image_data)

                    jewellery_data_list.append(jewellery_data)

                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'jewellery': jewellery_data_list
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code': 404, 'error': 'No jewellery found'}), headers=headers, status=404)

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), headers={'Content-Type': 'application/json'}, status=500)

    @http.route('/api/v1/get_metal', auth='none', type='http', methods=['GET', 'POST'], cors='*', csrf=False)
    def get_metal_by_id(self, **kw):
        try:
            # Fetch the metal record
            metal_record = request.env['metal'].sudo().search([])
            if not metal_record.exists():
                return request.make_response(json.dumps({'code': 404, 'error': 'Metal not found'}), headers=[('Content-Type', 'application/json')])
            if metal_record.exists():
                serialized_metal = []
                for metal in metal_record:
                    serialized_metal.append({
                        'id': metal.id,
                        'value': metal.metal_name,
                    })

            headers = {'Content-Type': 'application/json'}
            body = {
                'results': {'code': 200, 'message': 'OK'},
                'categories': serialized_metal
            }
            return Response(json.dumps(body), headers=headers)

        except Exception as e:
            return request.make_response(json.dumps({'code': 500, 'error': str(e)}), headers=[('Content-Type', 'application/json')])

    @http.route('/api/v1/get_selected_jewellery', auth='none', type='http', methods=['POST', 'GET'], cors='*', csrf=False)
    def get_selected_jewellery(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            type_name = data.get('type_name')
            metal_name = data.get('metal_name', 'all')
            # Check if type_name is missing or empty
            if not (type_name ):
                return Response(json.dumps({'error': 'type_name is required.'}), status=400, content_type='application/json')

            sort_by_price = data.get('sort_by_price', 'default')
            filters = []
            if type_name != 'all':
                filters.append(('type.type_name', '=', type_name))

            jewellery_records = request.env['diamonds_rings_website.jewellery'].sudo().search(filters)

            if not metal_name == 'all':
                jewellery_records = jewellery_records.filtered(
                    lambda x: x.metal.metal_name == metal_name)

            # Sort jewellery_records based on the sort parameter
            if sort_by_price == 'price_low_high':
                jewellery_records = jewellery_records.sorted(
                    key=lambda p: p.price)
            elif sort_by_price == 'price_high_low':
                jewellery_records = jewellery_records.sorted(
                    key=lambda p: p.price, reverse=True)
            elif sort_by_price == 'default':
                jewellery_records = jewellery_records

            headers = {'Content-Type': 'application/json'}
            if jewellery_records:
                jewellery_list = []
                for jewellery in jewellery_records:
                    image_lines = []
                    for image in jewellery.image_lines:
                        # video_file_base64 = base64.b64encode(image.video_file).decode(
                        #     'utf-8') if image.video_file else ""
                        image_data = {
                            'id': image.id,
                            'image_type_name': image.image_type_name,
                            'video_file': image.video_file_attachment_id.url if image.video_file_attachment_id else "",
                            'images_urls': [],
                            'shape_value': image.shape_value,
                            'metal_value': image.metal_value,
                        }
                        for attachment in image.image_file:
                            if attachment.url:
                                # image_base64 = base64.b64encode(
                                #     attachment.datas).decode('utf-8')
                                image_data['images_urls'].append(
                                    attachment.url)

                        image_lines.append(image_data)

                    jewellery_list.append({
                        'id': jewellery.id,
                        'name': jewellery.name,
                        'desc': jewellery.desc,
                        # 'metal': jewellery.metal.metal_name,
                        'metal': [metal.metal_name for metal in jewellery.metal],
                        'category': jewellery.category.category_name if jewellery.category else '',
                        'type': jewellery.type.type_name if jewellery.type else '',
                        'price': jewellery.price,
                        'discount_price': jewellery.discount_price,
                        'images': image_lines,
                        'sku': jewellery.sku or ""
                    })
                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'jewellery': jewellery_list
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'results': {'code': 404, 'message': 'No jewellery found'}}), headers=headers, status=404)

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), headers={'Content-Type': 'application/json'}, status=500)

    @http.route('/api/v1/get_id_jewellery', auth='none', type='http', methods=['GET', 'POST'], cors='*', csrf=False)
    def get_id_jewellery(self, **kw):
        try:
            print('Request received: /api/v1/get_id_jewellery')
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            model_id = data.get('id')
            print(f'Model ID: {model_id}')

            if not model_id:
                return Response(json.dumps({'code': 400, 'error': 'Model ID is required'}), status=400, content_type='application/json')

            jewellery_record = request.env['diamonds_rings_website.jewellery'].sudo(
            ).browse(int(model_id))
            if jewellery_record.exists():
                jewellery_data = []
                metal_names = [
                    metal.metal_name for metal in jewellery_record.metal]
                record_data = {
                    'id': jewellery_record.id,
                    'name': jewellery_record.name,
                    'desc': jewellery_record.desc,
                    'category': jewellery_record.category.category_name if jewellery_record.category else '',
                    'type': jewellery_record.type.type_name if jewellery_record.type else '',
                    'price': jewellery_record.price,
                    'discount_price': jewellery_record.discount_price,
                    'metal': metal_names,
                    'sku': jewellery_record.sku,
                    'image_lines': [],
                    'diamond_number': jewellery_record.diamond_number,
                    'added_values': [],
                }

                for image in jewellery_record.image_lines:
                    # video_file_base64 = base64.b64encode(image.video_file).decode(
                    #     'utf-8') if image.video_file else ""
                    image_data = {
                        'id': image.id,
                        'image_type_name': image.image_type_name,
                        'video_file': image.video_file_attachment_id.url if image.video_file_attachment_id else "",
                        'images_urls': [],
                        'shape_value': image.shape_value,
                        'metal_value': image.metal_value,
                    }
                    for attachment in image.image_file:
                        if attachment.url:
                            # image_base64 = base64.b64encode(
                            #     attachment.datas).decode('utf-8')
                            image_data['images_urls'].append(attachment.url)

                    record_data['image_lines'].append(image_data)

                for added_value in jewellery_record.added_values:
                    added_value_data = {
                        'id': added_value.id,
                        'name': added_value.attribute_name,
                        'value': added_value.value_name,
                        'price': added_value.price,
                        'new_price': added_value.new_price,
                        'setting_type': added_value.setting_type,
                        'width': added_value.width,
                        'rodium_plated': added_value.rodium_plated,
                        'number_of_stones': added_value.number_of_stones,
                        'shape': added_value.shape,
                        'carat': added_value.carat,
                        'cut': added_value.cut,
                        'clarity': added_value.clarity,
                        'color': added_value.color,
                        'length': added_value.length,
                        'clasp': added_value.clasp,
                        'chain_type': added_value.chain_type,
                    }
                    record_data['added_values'].append(added_value_data)

                rules_data = []
                for rule in jewellery_record.rules:
                    attribute_values = [
                        {'id': value.id, 'value_name': value.value_name} for value in rule.attribute_values]
                    rule_data = {
                        'id': rule.id,
                        'attribute_name': rule.attribute_id.attribute_name,
                        'attribute_values': attribute_values
                    }
                    rules_data.append(rule_data)

                record_data['rules'] = rules_data

                jewellery_data.append(record_data)

                headers = {'Content-Type': 'application/json'}
                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'data': jewellery_data,
                }
                return Response(json.dumps(body), headers=headers)
            else:
                print(f'Jewellery record with ID {model_id} not found')
                return Response(json.dumps({'code': 404, 'error': 'Jewellery not found'}), status=404, content_type='application/json')

        except Exception as e:
            print(f'Error: {str(e)}')
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    # @http.route('/api/v1/get_jewellery_by_filterd_values', auth='none', type='http', methods=['POST'], cors='*', csrf=False)
    # def get_jewellery_by_id(self, **kw):
    #     try:
    #         request_body = request.httprequest.data.decode('utf-8')
    #         data = json.loads(request_body)
    #         model_id = data.get('model_id')
    #         shape = data.get('shape')
    #         carat = data.get('carat')
    #
    #         if not model_id:
    #             return request.make_response(json.dumps({'code': 400, 'error': 'Model ID is required'}), headers=[('Content-Type', 'application/json')])
    #
    #         jewellery_record = request.env['diamonds_rings_website.jewellery'].sudo(
    #         ).browse(int(model_id))
    #
    #         if not jewellery_record:
    #             return request.make_response(json.dumps({'code': 404, 'error': 'Jewellery not found'}), headers=[('Content-Type', 'application/json')])
    #
    #         filtered_diamonds = jewellery_record.filtered_diamond_ids.filtered(
    #             lambda d: d.shape and d.shape.value_name == shape and d.diamond_size  == float(carat))
    #
    #         diamond_data = [
    #             {
    #                 'id': diamond.id,
    #                 'diamond_id': diamond.diamond_id,
    #                 'shape': diamond.shape.value_name,
    #                 'diamond_size': diamond.diamond_size ,
    #                 'color': diamond.color.value_name,
    #                 'clarity': diamond.clarity.value_name,
    #                 'cut': diamond.cut.value_name,
    #                 'symmetry': diamond.symmetry.value_name,
    #                 'polish': diamond.polish.value_name,
    #                 'fluor_intensity': diamond.fluor_intensity.value_name,
    #                 'lab': diamond.lab,
    #                 'image_file': diamond.image_file,
    #                 'total_sales_price': diamond.total_sales_price,
    #
    #             } for diamond in filtered_diamonds]
    #
    #         return request.make_response(json.dumps({'code': 200, 'diamonds': diamond_data}), headers=[('Content-Type', 'application/json')])
    #
    #     except Exception as e:
    #         return request.make_response(json.dumps({'code': 500, 'error': str(e)}), headers=[('Content-Type', 'application/json')])

    @http.route('/api/v1/get_jewelleries_by_filter', auth='none', type='http', method=['POST', 'GET'], cors='*',
                csrf=False)
    def get_jewelleries_by_filter(self, **kw):
        try:
            request_body = http.request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            type = data.get('type')
            metal = data.get('metal')
            category = data.get('category_id')
            sort = data.get('sort')
            is_design_available = data.get('is_design_available', False)

            # Check if type is missing or empty
            if not (type and metal and category):
                return Response(json.dumps({'code': 400, 'error': 'type, metal and category_id are required and cannot be empty'}),
                                status=400, content_type='application/json')
            domain =[]

            if type != "all":
                domain += [('type', '=', type), ('metal', 'in', metal), ('category', '=', category)]

                # jewellery_records = http.request.env['diamonds_rings_website.jewellery'].sudo(
                # ).search([('type', '=', type), ('metal', 'in', metal), ('category', '=', category)])

            else:
                domain += [('metal', 'in', metal), ('category', '=', category)]
                # jewellery_records = http.request.env['diamonds_rings_website.jewellery'].sudo(
                # ).search([('metal', 'in', metal), ('category', '=', category)])

            if is_design_available:
                domain.append(('is_available_for_design', '=', True))

            jewellery_records = http.request.env['diamonds_rings_website.jewellery'].sudo(
            ).search(domain)
            if sort == 'low':
                jewellery_records = jewellery_records.sorted(key='price')

            if sort == 'high':
                jewellery_records = jewellery_records.sorted(key='price', reverse=True)

            headers = {'Content-Type': 'application/json'}
            jewellery_data_list = []
            _logger.info("Count is : {}".format(len(jewellery_records)))
            if jewellery_records:
                jewellery_data = []
                for jewellery in jewellery_records:
                    jewellery_data = {
                        'id': jewellery.id,
                        'name': jewellery.name,
                        'metal': [metal.metal_name for metal in jewellery.metal],
                        'category': jewellery.category.category_name if jewellery.category else '',
                        'type': jewellery.type.type_name if jewellery.type else '',
                        'sku': jewellery.sku,
                        'desc': jewellery.desc,
                        'price': jewellery.price,
                        'discount_price': jewellery.discount_price,
                        'image_lines': []
                    }
                    for image in jewellery.image_lines:
                        # video_file_base64 = base64.b64encode(image.video_file).decode(
                        #     'utf-8') if image.video_file else ""
                        image_data = {
                            'id': image.id,
                            'image_type_name': image.image_type_name,
                            'video_file': image.video_file_attachment_id.url if image.video_file_attachment_id else "",
                            'images_urls': [],
                            'shape_value': image.shape_value,
                            'metal_value': image.metal_value,
                        }
                        for attachment in image.image_file:
                            if attachment.url:
                                # image_base64 = base64.b64encode(
                                #     attachment.datas).decode('utf-8')
                                image_data['images_urls'].append(
                                    attachment.url)

                        jewellery_data['image_lines'].append(image_data)

                    jewellery_data_list.append(jewellery_data)

                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'jewellery': jewellery_data_list
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code': 404, 'error': 'No jewellery found'}), headers=headers, status=404)

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), headers={'Content-Type': 'application/json'},
                            status=500)

    @http.route('/api/v1/get_jewelleries_for_view', auth='none', type='http', method=['POST', 'GET'], cors='*',
                csrf=False)
    def get_jewelleries_for_view(self, **kw):
        try:
            request_body = http.request.httprequest.data.decode('utf-8')
            jewellery_records = []
            categories = http.request.env['diamonds_rings_website.category'].sudo(
            ).search([])
            for category in categories:
                rec = http.request.env['diamonds_rings_website.jewellery'].sudo(
                ).search([('category', '=', category.id)], limit =1)
                if rec:
                    jewellery_records.append(rec)

            headers = {'Content-Type': 'application/json'}
            jewellery_data_list = []

            if jewellery_records:
                jewellery_data = []
                for jewellery in jewellery_records:
                    jewellery_data = {
                        'id': jewellery.id,
                        'name': jewellery.name,
                        'category': jewellery.category.category_name if jewellery.category else '',
                        'type': jewellery.type.type_name if jewellery.type else '',
                        'sku': jewellery.sku,
                        'desc': jewellery.desc,
                        'price': jewellery.price,
                        'discount_price': jewellery.discount_price,
                        'image_lines': []
                    }
                    for image in jewellery.image_lines:
                        # video_file_base64 = base64.b64encode(image.video_file).decode(
                        #     'utf-8') if image.video_file else ""
                        image_data = {
                            'id': image.id,
                            'image_type_name': image.image_type_name,
                            'video_file': image.video_file_attachment_id.url if image.video_file_attachment_id else "",
                            'images_urls': [],
                            'shape_value': image.shape_value,
                            'metal_value': image.metal_value,
                        }
                        for attachment in image.image_file:
                            if attachment.url:
                                # image_base64 = base64.b64encode(
                                #     attachment.datas).decode('utf-8')
                                image_data['images_urls'].append(
                                    attachment.url)

                        jewellery_data['image_lines'].append(image_data)

                    jewellery_data_list.append(jewellery_data)

                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'jewellery': jewellery_data_list
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code': 404, 'error': 'No jewellery found'}), headers=headers, status=404)

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), headers={'Content-Type': 'application/json'},
                            status=500)