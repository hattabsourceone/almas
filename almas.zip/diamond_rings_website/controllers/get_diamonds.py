from odoo import http
from odoo.http import Response
import json
from odoo.http import request
from odoo.tools.safe_eval import datetime
from ..static.variables import cut_values, clarity_values, color_values


class DiamondController(http.Controller):
    def match_criteria(self,row1, row2):
        return (
                (row1["diamond_size"] >= row2["diamond_size"] - 0.2 and row1["diamond_size"] <= row2[
                    "diamond_size"] + 0.2) and
                (row1["co_order"] >= row2["co_order"] - 1 and row1["co_order"] <= row2[
                    "co_order"] + 1) and
                (row1["cu_order"] >= row2["cu_order"] - 1 and row1["cu_order"] <= row2["cu_order"] + 1) and
                (row1["cl_order"] >= row2["cl_order"] - 1 and row1["cl_order"] <= row2[
                    "cl_order"] + 1)
        )

    def group_into_pairs(self, data):
        used_indices = set()  # Keep track of paired rows
        pairs = []  # List to store the pairs
        for i, row1 in enumerate(data):
            if i in used_indices:
                continue
            for j, row2 in enumerate(data):
                if j in used_indices or i == j:
                    continue
                if self.match_criteria(row1, row2):
                    pairs.append((row1, row2))
                    used_indices.add(i)
                    used_indices.add(j)
                    break

        return pairs

    @http.route('/api/v1/get_all_diamonds', auth='none', type='http', method=['GET', 'POST'], cors='*', csrf=False)
    def get_all_diamonds(self, **kw):
        request_body = request.httprequest.data.decode('utf-8')
        data = json.loads(request_body)
        limit = int(data.get('limit', 10))  # Default 10
        total_records = http.request.env['diamonds_rings_website.diamond'].sudo().search_count([])
        total_pages = (total_records + limit - 1) // limit
        page = int(data.get('page', 1))  # Default 1
        offset = (page - 1) * limit
        sort_by = data.get('sort_by', 'price_low_high')
        if sort_by == 'price_low_high':
            products = http.request.env['diamonds_rings_website.diamond'].sudo().search([], limit=limit, offset=offset,
                                                                                        order="total_sales_price asc")
        elif sort_by == 'price_high_low':
            products = http.request.env['diamonds_rings_website.diamond'].sudo().search([], limit=limit, offset=offset,
                                                                                        order="total_sales_price desc")
        elif sort_by == 'carat_low_high':
            products = http.request.env['diamonds_rings_website.diamond'].sudo().search([], limit=limit, offset=offset,
                                                                                        order="diamond_size asc")
        elif sort_by == 'carat_high_low':
            products = http.request.env['diamonds_rings_website.diamond'].sudo().search([], limit=limit, offset=offset,
                                                                                        order="diamond_size desc")
        elif sort_by == 'cut_low_high':
            products = http.request.env['diamonds_rings_website.diamond'].sudo().search([], limit=limit, offset=offset,
                                                                                        order="cut_order asc")
        elif sort_by == 'cut_high_low':
            products = http.request.env['diamonds_rings_website.diamond'].sudo().search([], limit=limit, offset=offset,
                                                                                        order="cut_order desc")
        elif sort_by == 'color_high_low':
            products = http.request.env['diamonds_rings_website.diamond'].sudo().search([], limit=limit, offset=offset,
                                                                                        order="color_order desc")
        elif sort_by == 'color_low_high':
            products = http.request.env['diamonds_rings_website.diamond'].sudo().search([], limit=limit, offset=offset,
                                                                                        order="color_order asc")
        elif sort_by == 'clarity_high_low':
            products = http.request.env['diamonds_rings_website.diamond'].sudo().search([], limit=limit, offset=offset,
                                                                                        order="clarity_order desc")
        elif sort_by == 'clarity_low_high':
            products = http.request.env['diamonds_rings_website.diamond'].sudo().search([], limit=limit, offset=offset,
                                                                             order="clarity_order asc")
        else:
            products = http.request.env['diamonds_rings_website.diamond'].sudo().search([], limit=limit, offset=offset)

        product_data = []
        for product in products:
            product_data.append({
                'id': product.id,
                'diamond_id': product.diamond_id if product.diamond_id else "",
                'shape': product.shape.serialize() if product.shape else "",
                'diamond_size': product.diamond_size if product.diamond_size else "",
                'color': product.color.serialize() if product.color else "" ,
                'clarity': product.clarity.serialize() if product.clarity else "",
                'cut': product.cut.serialize() if product.cut else "" ,
                'symmetry': product.symmetry.serialize() if product.symmetry else "",
                'polish': product.polish.serialize() if product.polish else "",
                'fluor_intensity': product.fluor_intensity.serialize() if product.fluor_intensity else "",
                'lab': product.lab if product.lab else "",
                'image_file': product.image_file if product.image_file else "",
                'total_sales_price': product.total_sales_price if product.total_sales_price else "",
                'meas_length': product.meas_length if product.meas_length else "",
                'meas_width': product.meas_width if product.meas_width else "",
                'meas_depth': product.meas_depth if product.meas_depth else "",
                'table': product.table_percent if product.table_percent else "",
                'depth': product.depth_percent if product.depth_percent else "",
                "video_url": product.video_url if product.video_url else "",
                "stock_num": product.stock_num if product.stock_num else "",
                "culet_size": product.culet_size.serialize() if product.culet_size else "",
                "culet_condition": product.culet_condition if product.culet_condition else ""
            })
        # products = http.request.env['diamonds_rings_website.diamond'].sudo().search([])
        # request_body = request.httprequest.data.decode('utf-8')
        # data = json.loads(request_body)
        # # Pagination parameters
        # limit = int(data.get('limit', 10)) # Default 10
        # total_records = len(products)
        # total_pages = (total_records + limit - 1) // limit
        # page = int(data.get('page', 1)) # Default 1
        # start_index = (page - 1) * limit
        # end_index = min(start_index + limit, total_records)
        # # Sorting parameter
        # sort_by = data.get('sort_by', 'price_low_high')
        #
        # # Sort products based on the sort_by parameter
        # if sort_by == 'price_low_high':
        #     products = products.sorted(key=lambda p: p.total_sales_price)
        # elif sort_by == 'price_high_low':
        #     products = products.sorted(key=lambda p: p.total_sales_price, reverse=True)
        # elif sort_by == 'carat_low_high':
        #     products = products.sorted(key=lambda p: p.diamond_size)
        # elif sort_by == 'carat_high_low':
        #     products = products.sorted(key=lambda p: p.diamond_size, reverse=True)
        # elif sort_by == 'cut_low_high':
        #     products = products.sorted(key=lambda p: cut_values.get(p.cut.value_name, 0))
        # elif sort_by == 'cut_high_low':
        #     products = products.sorted(key=lambda p: cut_values.get(p.cut.value_name, 0), reverse=True)
        # elif sort_by == 'color_high_low':
        #     products = products.sorted(key=lambda p: color_values.get(p.color.value_name, 0), reverse=True)
        # elif sort_by == 'color_low_high':
        #     products = products.sorted(key=lambda p: color_values.get(p.color.value_name, 0))
        # elif sort_by == 'clarity_high_low':
        #     products = products.sorted(key=lambda p: clarity_values.get(p.clarity.value_name, 0), reverse=True)
        # elif sort_by == 'clarity_low_high':
        #     products = products.sorted(key=lambda p: clarity_values.get(p.clarity.value_name, 0))
        #
        # product_data = []
        # for product in products[start_index:end_index]:
        #     product_data.append({
        #         'id': product.id,
        #         'diamond_id': product.diamond_id if product.diamond_id else "",
        #         'shape': product.shape.serialize() if product.shape else "",
        #         'diamond_size': product.diamond_size if product.diamond_size else "",
        #         'color': product.color.serialize() if product.color else "" ,
        #         'clarity': product.clarity.serialize() if product.clarity else "",
        #         'cut': product.cut.serialize() if product.cut else "" ,
        #         'symmetry': product.symmetry.serialize() if product.symmetry else "",
        #         'polish': product.polish.serialize() if product.polish else "",
        #         'fluor_intensity': product.fluor_intensity.serialize() if product.fluor_intensity else "",
        #         'lab': product.lab if product.lab else "",
        #         'image_file': product.image_file if product.image_file else "",
        #         'total_sales_price': product.total_sales_price if product.total_sales_price else "",
        #         'meas_length': product.meas_length if product.meas_length else "",
        #         'meas_width': product.meas_width if product.meas_width else "",
        #         'meas_depth': product.meas_depth if product.meas_depth else "",
        #         'table': product.table_percent if product.table_percent else "",
        #         'depth': product.depth_percent if product.depth_percent else "",
        #         "video_url": product.video_url if product.video_url else "",
        #         "stock_num": product.stock_num if product.stock_num else "",
        #         "culet_size": product.culet_size.serialize() if product.culet_size else "",
        #         "culet_condition": product.culet_condition if product.culet_condition else ""
        #     })
        # Prepare the response
        headers = {'Content-Type': 'application/json'}
        if product_data:
            body = {
                'results': {'code': 200, 'message': 'OK'},
                'data': product_data,
                'total_pages': total_pages
            }
            # Serialize the response data and return
            return Response(json.dumps(body), headers=headers)
        else:
            return Response(json.dumps({'code': 404, 'error': 'No categories found'}), status=404,
                            content_type='application/json')

    @http.route('/api/v1/get_selected_diamonds', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def get_selected_diamonds(self, **post):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            shapes = data.get('shape', [])
            min_price = data.get('min_price')
            max_price = data.get('max_price')
            min_carat = data.get('min_carat')
            max_carat = data.get('max_carat')
            cuts = data.get('cut', [])
            colors = data.get('color', [])
            clarities = data.get('clarity', [])
            certificate = data.get('certificate')

            # Apply filters
            domain = []
            if shapes:
                domain.append(('shape', 'in', shapes))
            if min_price is not None and max_price is not None:
                domain.append(('total_sales_price', '>=', min_price))
                domain.append(('total_sales_price', '<=', max_price))
            if min_carat is not None and max_carat is not None:
                domain.append(('diamond_size', '>=', min_carat))
                domain.append(('diamond_size', '<=', max_carat))
            if cuts:
                if "" in cuts:
                    domain.append('|')
                    domain.append(('cut', '=', False))
                non_empty_cuts = [cut for cut in cuts if cut]
                if non_empty_cuts:
                    domain.append(('cut', 'in', non_empty_cuts))
            if colors:
                domain.append(('color', 'in', colors))
            if clarities:
                domain.append(('clarity', 'in', clarities))
            if certificate:
                domain.append(('lab', '=', "GIA"))

            if domain:
                limit = int(data.get('limit', 10))  # Default 10
                total_records = http.request.env['diamonds_rings_website.diamond'].sudo().search_count(domain)
                total_pages = (total_records + limit - 1) // limit
                page = int(data.get('page', 1))  # Default 1
                offset = (page - 1) * limit

                sort_by = data.get('sort_by', 'default')
                if sort_by == 'price_low_high':
                    products = http.request.env['diamonds_rings_website.diamond'].sudo().search(domain, limit=limit,
                                                                                                offset=offset,
                                                                                                order="total_sales_price asc")
                elif sort_by == 'price_high_low':
                    products = http.request.env['diamonds_rings_website.diamond'].sudo().search(domain, limit=limit,
                                                                                                offset=offset,
                                                                                                order="total_sales_price desc")
                elif sort_by == 'carat_low_high':
                    products = http.request.env['diamonds_rings_website.diamond'].sudo().search(domain, limit=limit,
                                                                                                offset=offset,
                                                                                                order="diamond_size asc")
                elif sort_by == 'carat_high_low':
                    products = http.request.env['diamonds_rings_website.diamond'].sudo().search(domain, limit=limit,
                                                                                                offset=offset,
                                                                                                order="diamond_size desc")
                elif sort_by == 'cut_low_high':
                    products = http.request.env['diamonds_rings_website.diamond'].sudo().search(domain, limit=limit,
                                                                                                offset=offset,
                                                                                                order="cut_order asc")
                elif sort_by == 'cut_high_low':
                    products = http.request.env['diamonds_rings_website.diamond'].sudo().search(domain, limit=limit,
                                                                                                offset=offset,
                                                                                                order="cut_order desc")
                elif sort_by == 'color_high_low':
                    products = http.request.env['diamonds_rings_website.diamond'].sudo().search(domain, limit=limit,
                                                                                                offset=offset,
                                                                                                order="color_order desc")
                elif sort_by == 'color_low_high':
                    products = http.request.env['diamonds_rings_website.diamond'].sudo().search(domain, limit=limit,
                                                                                                offset=offset,
                                                                                                order="color_order asc")
                elif sort_by == 'clarity_high_low':
                    products = http.request.env['diamonds_rings_website.diamond'].sudo().search(domain, limit=limit,
                                                                                                offset=offset,
                                                                                                order="clarity_order desc")
                elif sort_by == 'clarity_low_high':
                    products = http.request.env['diamonds_rings_website.diamond'].sudo().search(domain, limit=limit,
                                                                                                offset=offset,
                                                                                                order="clarity_order asc")
                else:
                    products = http.request.env['diamonds_rings_website.diamond'].sudo().search(domain, limit=limit,
                                                                                                offset=offset)
                product_data = [
                    {
                        'id': product.id,
                        'diamond_id': product.diamond_id if product.diamond_id else "",
                        'shape': product.shape.serialize() if product.shape else "",
                        'diamond_size': product.diamond_size if product.diamond_size else "",
                        'color': product.color.serialize() if product.color else "",
                        'clarity': product.clarity.serialize() if product.clarity else "",
                        'cut': product.cut.serialize() if product.cut else "",
                        'symmetry': product.symmetry.serialize() if product.symmetry else "",
                        'polish': product.polish.serialize() if product.polish else "",
                        'fluor_intensity': product.fluor_intensity.serialize() if product.fluor_intensity else "",
                        'lab': product.lab if product.lab else "",
                        'image_file': product.image_file if product.image_file else "",
                        'total_sales_price': product.total_sales_price if product.total_sales_price else "",
                        'meas_length': product.meas_length if product.meas_length else "",
                        'meas_width': product.meas_width if product.meas_width else "",
                        'meas_depth': product.meas_depth if product.meas_depth else "",
                        'table': product.table_percent if product.table_percent else "",
                        'depth': product.depth_percent if product.depth_percent else "",
                        "video_url": product.video_url if product.video_url else "",
                        "stock_num": product.stock_num if product.stock_num else "",
                        "culet_size": product.culet_size.serialize() if product.culet_size else "",
                        "culet_condition": product.culet_condition if product.culet_condition else ""
                    }
                    for product in products
                ]

                headers = {'Content-Type': 'application/json'}
                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'data': product_data,
                    'total_pages': total_pages
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return self.get_all_diamonds()

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500,
                            headers={'Content-Type': 'application/json'})

    @http.route('/api/v1/get_selected_sorted_diamonds', auth='none', type='http', methods=['POST'], csrf=False,
                cors='*')
    def get_selected_sorted_diamonds(self, **post):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            shapes = data.get('shape', [])
            min_price = data.get('min_price')
            max_price = data.get('max_price')
            min_carat = data.get('min_carat')
            max_carat = data.get('max_carat')
            cuts = data.get('cut', [])
            colors = data.get('color', [])
            clarities = data.get('clarity', [])
            certificate = data.get('certificate')

            # Apply filters
            domain = []
            if shapes:
                domain.append(('shape', 'in', shapes))
            if min_price is not None and max_price is not None:
                domain.append(('total_sales_price', '>=', min_price))
                domain.append(('total_sales_price', '<=', max_price))
            if min_carat is not None and max_carat is not None:
                domain.append(('diamond_size', '>=', min_carat))
                domain.append(('diamond_size', '<=', max_carat))
            if cuts:
                if "" in cuts:
                    domain.append('|')
                    domain.append(('cut', '=', False))
                non_empty_cuts = [cut for cut in cuts if cut]
                if non_empty_cuts:
                    domain.append(('cut', 'in', non_empty_cuts))
            if colors:
                domain.append(('color', 'in', colors))
            if clarities:
                domain.append(('clarity', 'in', clarities))
            if certificate:
                domain.append(('lab', '=', "GIA"))

            if domain:
                # products = http.request.env['diamonds_rings_website.diamond'].sudo().search(domain)
                limit = int(data.get('limit', 10))  # Default 10
                total_records = http.request.env['diamonds_rings_website.diamond'].sudo().search_count(domain)
                total_pages = (total_records + limit - 1) // limit
                page = int(data.get('page', 1))  # Default 1
                offset = (page - 1) * limit
                products = http.request.env['diamonds_rings_website.diamond'].sudo().search(domain, limit=limit,
                                                                                            offset=offset,
                                                                                            order="diamond_size asc, color_order asc, cut_order asc, clarity_order asc")
                product_data = [
                    {
                        'id': product.id,
                        'diamond_id': product.diamond_id if product.diamond_id else "",
                        'shape': product.shape.serialize() if product.shape else "",
                        'diamond_size': product.diamond_size if product.diamond_size else "",
                        'color': product.color.serialize() if product.color else "",
                        'clarity': product.clarity.serialize() if product.clarity else "",
                        'cut': product.cut.serialize() if product.cut else "",
                        'symmetry': product.symmetry.serialize() if product.symmetry else "",
                        'polish': product.polish.serialize() if product.polish else "",
                        'fluor_intensity': product.fluor_intensity.serialize() if product.fluor_intensity else "",
                        'lab': product.lab if product.lab else "",
                        'image_file': product.image_file if product.image_file else "",
                        'total_sales_price': product.total_sales_price if product.total_sales_price else "",
                        'meas_length': product.meas_length if product.meas_length else "",
                        'meas_width': product.meas_width if product.meas_width else "",
                        'meas_depth': product.meas_depth if product.meas_depth else "",
                        'table': product.table_percent if product.table_percent else "",
                        'depth': product.depth_percent if product.depth_percent else "",
                        "video_url": product.video_url if product.video_url else "",
                        "stock_num": product.stock_num if product.stock_num else "",
                        "culet_size": product.culet_size.serialize() if product.culet_size else "",
                        "culet_condition": product.culet_condition if product.culet_condition else "",
                        "co_order": product.color_order,
                        "cu_order": product.cut_order,
                        "cl_order": product.clarity_order,
                    }
                    for product in products
                ]

                pairs = self.group_into_pairs(product_data)
                items = [item for tup in pairs for item in tup]
                headers = {'Content-Type': 'application/json'}
                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'data': items,
                    'total_pages': total_pages
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return self.get_all_diamonds()

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500,
                            headers={'Content-Type': 'application/json'})

    @http.route('/api/v1/get_diamond_by_id', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def get_diamond_by_id(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            model_id = data.get('model_id')

            if not model_id:
                return Response(json.dumps({'code': 400, 'error': 'model_id is required'}), status=400,
                                content_type='application/json')

            # Retrieve the diamond record based on the model ID
            diamond = request.env['diamonds_rings_website.diamond'].sudo().browse(int(model_id))

            # Check if the diamond exists
            if diamond.exists():
                # Prepare the response data
                diamond_data = {
                    'id': diamond.id,
                    'diamond_id': diamond.diamond_id,
                    'shape': diamond.shape.serialize() if diamond.shape else "",
                    'diamond_size': diamond.diamond_size,
                    'color': diamond.color.serialize() if diamond.color else "",
                    'clarity': diamond.clarity.serialize() if diamond.clarity else "",
                    'cut': diamond.cut.serialize() if diamond.cut else "",
                    'symmetry': diamond.symmetry.serialize() if diamond.symmetry else "",
                    'polish': diamond.polish.serialize() if diamond.polish else "",
                    'fluor_intensity': diamond.fluor_intensity.serialize() if diamond.fluor_intensity else "",
                    'lab': diamond.lab if diamond.lab else "",
                    'image_file': diamond.image_file if diamond.image_file else "",
                    'total_sales_price': diamond.total_sales_price if diamond.total_sales_price else "",
                    'depth': diamond.depth_percent if diamond.depth_percent else "",
                    'table': diamond.table_percent if diamond.table_percent else "",
                    'meas_length': diamond.meas_length if diamond.meas_length else "",
                    'meas_width': diamond.meas_width if diamond.meas_width else "",
                    'meas_depth': diamond.meas_depth if diamond.meas_depth else "",
                    "video_url": diamond.video_url if diamond.video_url else "",
                    "stock_num": diamond.stock_num if diamond.stock_num else "",
                    "culet_size": diamond.culet_size.serialize() if diamond.culet_size else "",
                    "culet_condition": diamond.culet_condition if diamond.culet_condition else ""
                }
                # Prepare the response
                headers = {'Content-Type': 'application/json'}
                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'data': diamond_data,
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code': 404, 'error': 'Diamond not found'}), status=404,
                                content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/get_filters', auth='none', type='http', methods=['GET'], cors='*')
    def get_filters(self, **kw):
        try:
            diamonds = request.env['diamonds_rings_website.diamond'].sudo().search([])

            if diamonds:
                max_price = max(diamonds.mapped('total_sales_price'))
                min_price = min(diamonds.mapped('total_sales_price'))
                max_carat = max(diamonds.mapped('diamond_size'))
                min_carat = min(diamonds.mapped('diamond_size'))
                colors = list(set(diamonds.mapped('color.value_name')))
                clarities = list(set(diamonds.mapped('clarity.value_name')))
                shapes = list(set(diamonds.mapped('shape.value_name')))

                body = {
                    'results': {'code': 200, '                               message': 'OK'},
                    'data': {
                        'max_price': max_price,
                        'min_price': min_price,
                        'max_carat': max_carat,
                        'min_carat': min_carat,
                        'colors': colors,
                        'clarities': clarities,
                        'shapes': shapes
                    }
                }
                return Response(json.dumps(body), headers={'Content-Type': 'application/json'})
            else:
                return Response(json.dumps({'code': 404, 'error': 'No diamonds found'}), status=404,
                                headers={'Content-Type': 'application/json'})

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500,
                            headers={'Content-Type': 'application/json'})

    @http.route('/api/v1/get_glimpse_diamond', auth='none', type='http', methods=['GET'], csrf=False, cors='*')
    def get_glimpse(self):
        try:
            shapes = ['Round', 'Heart', 'Princess', 'Emerald']
            diamonds = []

            for shape in shapes:
                diamond = request.env['diamonds_rings_website.diamond'].sudo().search(
                    [('shape.value_name', '=', shape)], limit=1)
                if diamond:
                    diamond_data = {
                        'id': diamond.id,
                        'diamond_id': diamond.diamond_id,
                        'shape': diamond.shape.serialize() if diamond.shape else "",
                        'diamond_size': diamond.diamond_size,
                        'color': diamond.color.serialize() if diamond.color else "",
                        'clarity': diamond.clarity.serialize() if diamond.clarity else "",
                        'cut': diamond.cut.serialize() if diamond.cut else "",
                        'symmetry': diamond.symmetry.serialize() if diamond.symmetry else "",
                        'polish': diamond.polish.serialize() if diamond.polish else "",
                        'fluor_intensity': diamond.fluor_intensity.serialize() if diamond.fluor_intensity else "",
                        'image_file': diamond.image_file if diamond.image_file else "",
                        'meas_length': diamond.meas_length if diamond.meas_length else "",
                        'meas_width': diamond.meas_width if diamond.meas_width else "",
                        'meas_depth': diamond.meas_depth if diamond.meas_depth else "",
                        'table': diamond.table_percent if diamond.table_percent else "",
                        'depth': diamond.depth_percent if diamond.depth_percent else "",
                        'total_sales_price': diamond.total_sales_price if diamond.total_sales_price else "",
                    }
                    diamonds.append(diamond_data)

            if diamonds:
                response_data = {
                    'results': {'code': 200, 'message': 'OK'},
                    'data': diamonds,
                }
                return Response(json.dumps(response_data), content_type='application/json')
            else:
                return Response(json.dumps({'code': 404, 'error': 'No diamonds found'}), status=404,
                                content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')
