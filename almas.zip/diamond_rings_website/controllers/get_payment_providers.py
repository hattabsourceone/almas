import json
from odoo import http
from odoo.http import request, Response

class PaymentProviderController(http.Controller):

    @http.route('/api/v1/get_payment_methods', type='http', auth='none', methods=['GET'], cors='*')
    def get_payment_methods(self):
        try:
            providers = request.env['payment.provider'].sudo().search([('state', '=', 'enabled')])

            headers = {'Content-Type': 'application/json'}
            if providers:
                serialized_providers = []
                for provider in providers:
                    serialized_providers.append({
                        'id': provider.id,
                        'name': provider.name,
                        'code': provider.code,
                    })
                body = {
                    'results': {'code': 200, 'message': 'OK'},
                    'providers': serialized_providers
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code': 404, 'error': 'No providers found'}), status=404, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, headers={'Content-Type': 'application/json'})
