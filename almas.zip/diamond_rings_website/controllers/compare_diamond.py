from odoo import http
from odoo.http import request
from odoo.http import Response
import json
from datetime import datetime
import odoo

class CompareDiamondController(http.Controller):

    def _validate_session(self, data):
        session_id = data.get('session_id')
        uid = data.get('uid')
        if not session_id:
            return Response(json.dumps({'code': 400, 'error': 'Session ID is required.'}), status=400, content_type='application/json')

        session_in_come = request.session
        session_in_come.sid = session_id
        session_in_come.db = 'odoo17'
        session_in_come.uid = uid

        session = odoo.http.root.session_store.get(session_in_come.sid)

        if not session:
            return Response(json.dumps({'code': 401, 'error': 'Unauthorized.'}), status=401, content_type='application/json')

        if session.session_expiration and session.session_expiration < datetime.now():
            return Response(json.dumps({'code': 401, 'error': 'Session expired.'}), status=401, content_type='application/json')

        return session

    @http.route('/api/v1/add_to_compare_diamonds', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def add_to_compare_diamonds(self, **post):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session
            
            uid = request.session.uid
            diamond_id = data.get('diamond_id')
            added_date = datetime.today()

            required_fields = ['uid','diamond_id']
            if not all(data.get(field) for field in required_fields):
                return Response(json.dumps({'code': 400, 'error': 'Missing required fields'}), status=400, content_type='application/json')

            Diamond = request.env['diamonds_rings_website.diamond'].sudo()
            diamond = Diamond.search([('id', '=',int(diamond_id))])
            if not diamond.exists():
                return Response(json.dumps({'code': 404, 'error': 'Diamond not found'}), status=404, content_type='application/json')

            CompareDiamond = request.env['diamonds_rings_website.compare.diamond'].sudo()
            existing_compare = CompareDiamond.search([('customer', '=', uid), ('diamond_id', '=', diamond_id)])
            if existing_compare:
                return Response(json.dumps({'code': 400, 'error': 'Product already in compare list.'}), status=400, content_type='application/json')

            compare_diamonds_record = CompareDiamond.create({
                'customer': uid,
                'diamond_id': diamond_id,
                'added_date': added_date
            })

            headers = {'Content-Type': 'application/json'}
            if compare_diamonds_record:
                body = {
                    'results': {'code': 200, 'message': 'Product added to compare diamonds successfully'},
                    'id': compare_diamonds_record.id,
                    'uid': uid,
                    'diamond_id': diamond_id,
                    'added_date': str(added_date)
                }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code': 500, 'error': 'Failed to add product to compare diamonds'}), status=500, content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/remove_from_compare_diamonds', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def remove_from_compare_diamonds(self, **post):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)

            session = self._validate_session(data)
            if isinstance(session, Response):
                return session
            
            diamond_id = data.get('diamond_id')
            uid = request.session.uid

            if not diamond_id:
                return Response(json.dumps({'code': 400, 'error': 'Missing diamond_id field'}), status=400, content_type='application/json')

            CompareDiamond = request.env['diamonds_rings_website.compare.diamond'].sudo()
            compare_diamond_record = CompareDiamond.search([('customer', '=', uid), ('diamond_id', '=', diamond_id)])
            
            if not compare_diamond_record:
                return Response(json.dumps({'code': 404, 'error': 'Compare diamond record not found'}), status=404, content_type='application/json')

            compare_diamond_record.unlink()

            headers = {'Content-Type': 'application/json'}
            body = {
                'results': {'code': 200, 'message': 'Product removed from compare diamonds successfully'}
            }
            return Response(json.dumps(body), headers=headers)

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/get_compared_diamond', auth='none', type='http', methods=['GET','POST'], csrf=False, cors='*')
    def get_compared_diamond(self, **params):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid
            if not uid:
                return Response(json.dumps({'code': 400, 'error': 'uid is required'}), status=400, content_type='application/json')

            ComparedDiamond = request.env['diamonds_rings_website.compare.diamond'].sudo()
            compared_diamond_records = ComparedDiamond.search([('customer', '=', int(uid))])

            if not compared_diamond_records:
                return Response(json.dumps({'code': 404, 'error': 'No compared diamonds found'}), status=404, content_type='application/json')

            compared_diamond_data = []
            for record in compared_diamond_records:
                diamond = record.diamond_id
                compared_diamond_data.append({
                    'compared_diamond_id': record.id,
                    'uid': uid,
                    'diamond': {
                        'id': diamond.id,
                        'diamond_id': diamond.diamond_id,
                        'shape': diamond.shape.serialize() if diamond.shape else "", 
                        'diamond_size': diamond.diamond_size,
                        'color': diamond.color.serialize() if diamond.color else "",
                        'clarity': diamond.clarity.serialize() if diamond.clarity else "",
                        'cut': diamond.cut.serialize() if diamond.cut else "",
                        'symmetry': diamond.symmetry.serialize() if diamond.symmetry else "",
                        'polish': diamond.polish.serialize() if diamond.polish else "",
                        'fluor_intensity': diamond.fluor_intensity.serialize() if diamond.fluor_intensity else "",
                        'image_file': diamond.image_file if diamond.image_file else "",
                        'meas_length': diamond.meas_length if diamond.meas_length else "",
                        'meas_width': diamond.meas_width if diamond.meas_width else "",
                        'meas_depth': diamond.meas_depth if diamond.meas_depth else "",
                        'table': diamond.table_percent if diamond.table_percent else "",
                        'depth': diamond.depth_percent if diamond.depth_percent else "",
                    },
                    'added_date': record.added_date.isoformat()
                })

            response_data = {'results': {'code': 200, 'message': 'OK'}, 'data': compared_diamond_data}
            return Response(json.dumps(response_data), content_type='application/json')

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')
