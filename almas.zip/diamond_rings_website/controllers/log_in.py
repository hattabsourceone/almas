from odoo import http
from odoo.http import request
from werkzeug.utils import redirect
from odoo.exceptions import AccessError
from odoo.http import Response
import odoo
import json
from datetime import datetime


class CustomAuthController(http.Controller):
    def safe_get(self, value):
        return value if value else ""

    @http.route('/api/v1/get_authenticated_user', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def get_authenticated_user(self, **kw):
        request_body = request.httprequest.data.decode('utf-8')
        data = json.loads(request_body)
        session_id = data.get('session_id')
        uid = data.get('uid')
        if not session_id:
            return http.Response(json.dumps({'code': 400, 'error': 'Session ID is required.'}), status=400, content_type='application/json')

        session_in_come = request.session
        session_in_come.sid = session_id
        session_in_come.db = 'odoo17'
        session_in_come.uid = uid

        session = odoo.http.root.session_store.get(session_in_come.sid)

        if not session:
            return http.Response(json.dumps({'code': 401, 'error': 'Unauthorized.'}), status=401, content_type='application/json')

        if session.session_expiration and session.session_expiration < datetime.now():
            return http.Response(json.dumps({'code': 401, 'error': 'Session expired.'}), status=401, content_type='application/json')

        user = request.env['res.users'].sudo().search(
            [('id', '=', session.uid)])

        fields = ['id', 'full_name', 'mobile_w_country', 'address', 'city', 'post_code', 'country', 'state']
        response_body = {
            'results': {'code': 200, 'message': 'OK'},
            'session_id': session_id,
            'user': {
                'id': user.id,
                'name': user.name,
                'login': user.login,
                'phone': user.phone,
                'newsletter': self.safe_get(user.newsletter),
                'billing_full_name': json.dumps( self.safe_get(user.billing_ids.read(fields=fields))),
                'shipping_full_name': json.dumps( self.safe_get(user.shipping_ids.read(fields=fields))),
                'compared_diamonds_ids': [diamond.id for diamond in user.compared_diamonds_ids] or [],
                'wishlist_ids': [wishlist.id for wishlist in user.wishlist_ids] or [],
                'order_ids': [order.id for order in user.order_ids] or [],
            }
        }

        return Response(json.dumps(response_body), status=200, content_type='application/json')

    @http.route('/api/v1/check_token', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def check_token(self, **kw):
        request_body = request.httprequest.data.decode('utf-8')
        data = json.loads(request_body)
        session_id = data.get('session_id')
        uid = data.get('uid')
        if not session_id:
            return http.Response(json.dumps({'code': 400, 'error': 'Session ID is required.'}), status=400, content_type='application/json')
        session_in_come = request.session
        session_in_come.sid = session_id
        session_in_come.db = 'odoo17'
        session_in_come.uid = uid

        session = odoo.http.root.session_store.get(session_in_come.sid)

        if not session:
            return http.Response(json.dumps({'code': 401, 'error': 'Unauthorized.'}), status=401, content_type='application/json')

        if session.session_expiration and session.session_expiration < datetime.now():
            return http.Response(json.dumps({'code': 401, 'error': 'Session expired.'}), status=401, content_type='application/json')
        response_body = {
            'results': {'code': 200, 'message': 'OK'},
            'session_id': session_id,
        }
        return http.Response(json.dumps(response_body), status=200, content_type='application/json')

    @http.route('/api/v1/authenticate', auth='none', type='http', methods=['POST'], csrf=False, cors='*')
    def authenticate(self, **kw):
        request_body = request.httprequest.data.decode('utf-8')
        data = json.loads(request_body)

        login = data.get('login')
        db = data.get('db')
        password = data.get('password')

        if not http.db_filter([db]):
            raise AccessError("Database not found.")
        uid = request.session.authenticate(db, login, password)
        if not uid:
            return Response(json.dumps({'code': 401, 'error': 'Unauthorized.'}), status=401, content_type='application/json')

        odoo.http.root.session_store.save(request.session)
        response_body = {
            'results': {'code': 200, 'message': 'OK'},
            'uid': uid,
            'session_id': request.session.sid,
        }

        return Response(json.dumps(response_body), status=200, content_type='application/json')

    @http.route('/web/session/authenticate', type='http', auth="none", csrf=False, methods=['OPTIONS'])
    def authenticate_options(self, **kwargs):
        response = Response(status=200)
        return response

    @http.route('/web/login', type='http', auth='public', website=True, csrf=False)
    def custom_login(self, redirect_url=None, **kw):
        if request.httprequest.method == 'POST':
            request.params['login_success'] = False
            uid = request.session.authenticate(
                request.session.db, request.params['login'], request.params['password'])
            if uid:
                user = request.env['res.users'].browse(uid)
                public_group = request.env.ref('base.group_public')
                # if public_group in user.groups_id:
                # if user.status != 'CN':
                #     return {'error': 'User status is not confirmed'}
                # else:
                #     redirect_url = '/custom_page'
                # else:
                #     redirect_url = '/web'
                if public_group in user.groups_id:
                    redirect_url = '/custom_page'
                else:
                    redirect_url = '/web'
                request.params['login_success'] = True
                return redirect(redirect_url)
            else:
                return request.render('web.login', {
                    'error': 'Wrong login/password',
                    'databases': http.db_list(),
                })
        return request.render('web.login', {
            'databases': http.db_list(),
        })

    @http.route('/custom_page', type='http', auth='user', website=True)
    def custom_page(self, **kw):
        return request.render('diamond_rings_website.custom_page_template')
