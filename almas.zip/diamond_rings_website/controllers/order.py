# /addons/your_module_name/controllers/order_controller.py

from odoo import http, fields, models, api
from odoo.http import request, Response
import json
import odoo
from datetime import datetime
from werkzeug import urls


class OrderController(http.Controller):

    def _validate_session(self, data):
        session_id = data.get('session_id')
        uid = data.get('uid')
        if not session_id:
            # No session ID indicates a guest user
            return None

        session_in_come = request.session
        session_in_come.sid = session_id
        session_in_come.db = 'odoo17'
        session_in_come.uid = uid

        session = odoo.http.root.session_store.get(session_in_come.sid)

        if not session:
            return Response(json.dumps({'code': 401, 'error': 'Unauthorized.'}), status=401,
                            content_type='application/json')

        if session.session_expiration and session.session_expiration < datetime.now():
            return Response(json.dumps({'code': 401, 'error': 'Session expired.'}), status=401,
                            content_type='application/json')

        return session

    @http.route('/api/v1/send_cart_order', auth='none', type='http', methods=['POST'], cors='*', csrf=False)
    def send_cart_order(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            shipping_address = data.get('shipping_address')
            billing_address = data.get('billing_address')

            if not shipping_address or not billing_address:
                return Response(json.dumps({'code': 400, 'error': 'Shipping and Billing addresses are required'}),
                                status=400, content_type='application/json')

            _shipping_address = [request.env['res.shipping'].sudo().create(shipping_address).id]
            _billing_address = [request.env['res.billing'].sudo().create(billing_address).id]
            if session:
                # Authenticated user
                uid = request.session.uid if request.session.uid else data.get('uid')
            else:
                # Guest user
                uid = None

            amount = data.get('amount', 0.0)
            if amount <= 0:
                return Response(json.dumps({'code': 400, 'error': 'Amount must be greater than zero'}), status=400,
                                content_type='application/json')

            order = request.env['order'].sudo().create({
                'customer': uid if session else None,
                'purchase_date': fields.Datetime.now(),
                'cardholder_name': data.get('cardholder_name'),
                'card_number': data.get('card_number'),
                'expiration_date': data.get('expiration_date'),
                'security_code': data.get('security_code'),
                'shipping_address': _shipping_address,
                'billing_address': _billing_address,
                'jewellery_ids': [(6, 0, data.get('jewellery_ids', []))],
                'diamond_ids': [(6, 0, data.get('diamond_ids', []))],
                'amount': amount,
            })

            return Response(
                json.dumps({'code': 201, 'message': 'Order created', 'order_id': order.id, 'payment_link': order.link}),
                status=201, content_type='application/json')
        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')

    @http.route('/api/v1/get_orders', auth='none', type='http', methods=['POST'], cors='*', csrf=False)
    def get_orders(self, **kw):
        try:
            request_body = request.httprequest.data.decode('utf-8')
            data = json.loads(request_body)
            session = self._validate_session(data)
            if isinstance(session, Response):
                return session

            uid = request.session.uid
            orders = request.env['order'].sudo().search([('customer', '=', uid)])

            orders_data = []
            for order in orders:
                orders_data.append({
                    'id': order.id,
                    'purchase_date': order.purchase_date.strftime(
                        '%Y-%m-%d %H:%M') if order.purchase_date else order.purchase_date,
                    'status': order.status,
                    'shipping_address': order.shipping_address.serialize(),
                    'billing_address': order.billing_address.serialize(),
                    'amount': order.amount,
                    'jewellery_ids': [{'name': jewellery.jewellery_id.name, 'metal': jewellery.metal.metal_name,
                                       'shape': jewellery.shape, 'ring_size': jewellery.ring_size, 'price': jewellery.price,
                                       'sku': jewellery.jewellery_id.sku, 'category': jewellery.jewellery_id.category.category_name} for jewellery in
                                      order.jewellery_ids],
                    'diamond_ids': [
                        {'name': f"{diamond.diamond_size} - Carat {diamond.shape}", "carat": diamond.diamond_size,
                         'shape': diamond.shape, "cut": diamond.cut, 'color': diamond.color,
                         'clarity': diamond.clarity, 'polish': diamond.polish, 'symmetry': diamond.symmetry,
                         'fluor_intensity': diamond.fluor_intensity, "lab": diamond.lab, 'total_sales_price': diamond.total_sales_price,
                         "sku": diamond.stock_num} for diamond in order.diamond_history_ids],
                })

            return Response(json.dumps({'code': 200, 'orders': orders_data}), status=200,
                            content_type='application/json')
        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500, content_type='application/json')
