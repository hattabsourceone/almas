from odoo import http
from odoo.http import request, Response
import json
class QuestionController(http.Controller):

    @http.route('/api/v1/get_all_questions', auth='none', type='http', methods=['GET'], cors='*')
    def get_all_questions(self, **kw):
        try:
            questions = request.env['question'].sudo().search([])

            headers = {'Content-Type': 'application/json'}
            if questions:
                serialized_questions = []
                for qst in questions:
                    # Serialize each special offer
                    serialized_question = {
                        'id': qst.id,
                        'question': qst.question if qst.question else "",
                        'response': qst.response if qst.response else ""
                    }
                    serialized_questions.append(serialized_question)
                    body = {
                        'results': {'code': 200, 'message': 'OK'},
                        'id': qst.id,
                        'questions': serialized_questions
                    }
                return Response(json.dumps(body), headers=headers)
            else:
                return Response(json.dumps({'code': 404, 'error': 'No questions found'}),status=404 ,headers=headers)

        except Exception as e:
            return Response(json.dumps({'code': 500, 'error': str(e)}), status=500 ,headers={'Content-Type': 'application/json'})

