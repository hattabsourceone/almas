from datetime import timedelta
from odoo import models, fields, api

class TestWizard(models.TransientModel):
    _name = 'test.wizard'
    _description = 'Test Wizard'

    next_execution_date = fields.Datetime(string="Next Execution Date", readonly=True)
    last_execution_date = fields.Datetime(string="Last Execution Date", readonly=True)

    @api.model
    def default_get(self, fields):
        res = super(TestWizard, self).default_get(fields)
        next_execution_date = self.get_next_execution_date()
        res['next_execution_date'] = next_execution_date
        res['last_execution_date'] = self.get_last_execution_date(next_execution_date)
        return res

    def get_next_execution_date(self):
        cron_job = self.env['ir.cron'].search([('id', '=', self.env.ref('diamond_rings_website.update_data_cron').id)], limit=1)
        return cron_job.nextcall if cron_job else False

    def get_last_execution_date(self, next_execution_date):
        if not next_execution_date:
            return False

        cron_job = self.env['ir.cron'].search([('id', '=', self.env.ref('diamond_rings_website.update_data_cron').id)], limit=1)
        if not cron_job:
            return False

        interval_number = cron_job.interval_number
        interval_type = cron_job.interval_type

        interval_mapping = {
            'minutes': timedelta(minutes=interval_number),
            'hours': timedelta(hours=interval_number),
            'days': timedelta(days=interval_number),
            'weeks': timedelta(weeks=interval_number),
            'months': timedelta(days=30 * interval_number),  # Approximation
            'years': timedelta(days=365 * interval_number),  # Approximation
        }

        interval_delta = interval_mapping.get(interval_type, timedelta())

        last_execution_date = next_execution_date - interval_delta
        return last_execution_date
