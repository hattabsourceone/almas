{
    'name': 'Custom Button',
    'sequence': -100,
    'version': '1.0',
    'category': 'Uncategorized',
    'summary': 'Description ',
    'license': 'OEEL-1',
    'depends': ['base','diamond_rings_website'],
    'data': [
        'views/diamond_tree.xml',
        'wizards/test_wizard_view.xml',
        'security/ir.model.access.csv'
    ],
    'installable': True,
    'application': False,
    'auto_install': True,
    'assets': {
        'web.assets_backend': [
            '/custom_button/static/src/xml/tree_button.xml',
            '/custom_button/static/src/js/tree_button.js',
        ],
        'web.assets_web.min':[
            '/custom_button/static/src/js/tree_button.js',
        ]
    },
}
