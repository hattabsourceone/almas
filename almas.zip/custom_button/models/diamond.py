from odoo import models

class Diamond(models.Model):
    _inherit = 'diamonds_rings_website.diamond'
